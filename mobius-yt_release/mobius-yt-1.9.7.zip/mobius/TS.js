/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * @copyright KETI Korea 2015, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var url = require('url');
var xml2js = require('xml2js');
var get_retrieve = require('./retrieve');
var delete_delete = require('./delete');
var xmlbuilder = require('xmlbuilder');
var subscription = require('./subscription');
var util = require('util');
var DB = require('./db_action');
var js2xmlparser = require("js2xmlparser");
var http = require('http');

var _this = this;

const MISSINGDATAMAXNR = '1000';

function check_TS(level, resourceid, callback) {
    var options = {
        hostname: 'localhost',
        port: '7586',
        path: '/missingDataDetect',
        method: 'post',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': '12345',
            'Accept': 'application/xml',
            'X-M2M-Origin': 'Origin',
            'nmtype': 'long',
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var reqBodyString = '';
    var jsonObj = {};
    jsonObj.resourceid = resourceid;
    jsonObj.level = level.toString();
    reqBodyString = js2xmlparser('ts', JSON.stringify(jsonObj));

    var responseBody = '';
    var req = http.request(options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            responseBody += chunk;
        });

        res.on('end', function() {
            callback(res.headers['x-m2m-rsc'], responseBody);
        });
    });

    req.on('error', function (e) {
        if(e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    // write data to request body
    req.write(reqBodyString);
    req.end();
}



function delete_TS(level, resourceid, callback) {
    var options = {
        hostname: 'localhost',
        port: '7586',
        path: '/missingDataDetect',
        method: 'delete',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': '12345',
            'Accept': 'application/xml',
            'X-M2M-Origin': 'Origin',
            'nmtype': 'long'
        }
    };

    var reqBodyString = '';

    var responseBody = '';
    var req = http.request(options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            responseBody += chunk;
        });

        res.on('end', function() {
            callback(res.headers['x-m2m-rsc'], responseBody);
        });
    });

    req.on('error', function (e) {
        if(e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    // write data to request body
    req.write(reqBodyString);
    req.end();
}

function create_action( request, response, pool, resourcename, creator, accesscontrolpolicyids, expirationtime, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage, ontologyref, creationtime, level, parentid,
                        periodicinterval, missingdatadetect, missingdatamaxnr, missingdatalist, missingdatacurrentnr, missingdatadetecttimer) {
    // build timeSeries
    var resourcetype = 25;
    //var resourceid = randomValuehex(12);
    var cur_d = new Date();
    //var cur_o = cur_d.getTimezoneOffset()/(-60);
    //cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if((parseInt(cur_d.getMilliseconds(), 10)<10)) {
        msec = ('00'+cur_d.getMilliseconds());
    }
    else if((parseInt(cur_d.getMilliseconds(), 10)<100)) {
        msec = ('0'+cur_d.getMilliseconds());
    }
    else {
        msec = cur_d.getMilliseconds();
    }
    //var resourceid = 'TS' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '')+ msec + randomValueBase64(4);
    var resourceid = parentid + '/' + resourcename;

    var lastmodifiedtime = creationtime;

    if(expirationtime == '')
    {
        cur_d.setMonth(cur_d.getMonth() + 1);
        //if( cur_o < 10) {
        //    expirationtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
        //}
        //else {
            expirationtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
        //}
    }

    var statetag = 0;
    var currentnrofinstances = 0;
    var currentbytesize = 0;

    var sql = util.format('insert into lv%s (resourcetype, resourceid, resourcename, parentid, creationtime, lastmodifiedtime, expirationtime, accesscontrolpolicyids, statetag, labels, ' +
        'announceto, announcedattribute, creator, maxnrofinstances, maxbytesize, maxinstanceage, currentnrofinstances, currentbytesize, ontologyref, ' +
        'periodicinterval, missingdatadetect, missingdatamaxnr, missingdatalist, missingdatacurrentnr, missingdatadetecttimer) ' +
        'VALUE (' +
        '\'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', ' +
        '\'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\', ' +
        '\'%s\', \'%s\', \'%s\', \'%s\', \'%s\', \'%s\')',
        level + 1,
        resourcetype, resourceid, resourcename, parentid, creationtime, lastmodifiedtime, expirationtime, accesscontrolpolicyids, statetag, labels,
        announceto, announcedattribute, creator, maxnrofinstances, maxbytesize, maxinstanceage, currentnrofinstances, currentbytesize, ontologyref,
        periodicinterval, missingdatadetect, missingdatamaxnr, missingdatalist, missingdatacurrentnr, missingdatadetecttimer);

    DB.getResult(pool, sql, function (err, results) {
        if(!err) {
            sql = util.format("select * from lv%s where resourceid = \'%s\'", level+1, resourceid);
            DB.getResult(pool, sql, function (err, results_ts) {
                if(!err) {
                    if (results_ts.length == 1) {
                        subscription.check(request, pool, results_ts, level, parentid, 3);

                        check_TS(level+1, resourceid, function(rsc, responseBody) {
                            console.log(rsc + ' - ' + resourceid);
                            //console.log(responseBody);
                        });

                        response.setHeader('Content-Location', resourceid);
                        response.setHeader('X-M2M-RSC', '2001');
                        _this.retrieve(request, response, pool, results_ts, 201, level, resourceid);
                    }
                    else {
                        console.log('resource do not exist');
                        response.setHeader('X-M2M-RSC', '4004');
                        response.status(404).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"resource do not exist\"}' : '<rsp>resource do not exist</rsp>');
                    }
                }
                else {
                    console.log('query error: ' + results_ts.code);
                    response.setHeader('X-M2M-RSC', '5000');
                    response.status(500).end('<h1>' + results_ts.code + '</h1>');
                }
            });
        }
        else {
            if(results.code == 'ER_DUP_ENTRY') {
                check_TS(level+1, resourceid, function(rsc, responseBody) {
                    console.log(rsc);
                    console.log(responseBody);
                });
                response.setHeader('X-M2M-RSC', '4105');
                response.status(409).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"' + results.code + '\"}' : '<rsp>' + results.code + '</rsp>');
            }
            else {
                console.log('query error: ' + results.code);
                response.setHeader('X-M2M-RSC', '5000');
                response.status(500).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"' + results.code + '\"}' : '<rsp>' + results.code + '</rsp>');
            }
        }
    });
}

function parse_create_action(request, response, pool, creator, jsonObj, creationtime, level, parentid) {
    var rootnm = (request.headers.nmtype == 'long') ? ('m2m:timeSeries') : ('m2m:ts');

    if(jsonObj[rootnm] != null) {
        if(request.headers.nmtype == 'long') {
            // check NP
            if ((jsonObj[rootnm]['resourceType'] != null) || (jsonObj[rootnm]['resourceID'] != null) || (jsonObj[rootnm]['parentID'] != null) ||
                (jsonObj[rootnm]['creationTime'] != null) || (jsonObj[rootnm]['lastModifiedTime'] != null) || (jsonObj[rootnm]['stateTag'] != null) ||
                (jsonObj[rootnm]['creator'] != null) || (jsonObj[rootnm]['currentNrOfInstances'] != null) || (jsonObj[rootnm]['currentByteSize'] != null) ||
                (jsonObj[rootnm]['missingDataList'] != null) || (jsonObj[rootnm]['missingDataCurrentNr'] != null)) {
                console.log('Bad Request : Not Present Tag in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : Not Present Tag in body\"}' : '<rsp>Bad Request : Not Present Tag in body</rsp>');
            }
            // check M
            else if (0) {
                console.log('Bad Request : Mandatory Tag is none in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : Mandatory Tag is none in body\"}' : '<rsp>Bad Request : Mandatory Tag is none in body</rsp>');
            }
            else {
                var accesscontrolpolicyids = jsonObj[rootnm]['accessControlPolicyIDs'] == null ? '' : jsonObj[rootnm]['accessControlPolicyIDs'].toString().replace(/,/g, ' ');
                var expirationtime = jsonObj[rootnm]['expirationTime'] == null ? '' : jsonObj[rootnm]['expirationTime'];
                var labels = jsonObj[rootnm]['labels'] == null ? '' : jsonObj[rootnm]['labels'].toString().replace(/,/g, ' ');
                var announceto = jsonObj[rootnm]['announceTo'] == null ? '' : jsonObj[rootnm]['announceTo'].toString().replace(/,/g, ' ');
                var announcedattribute = jsonObj[rootnm]['announcedAttribute'] == null ? '' : jsonObj[rootnm]['announcedAttribute'].toString().replace(/,/g, ' ');
                creator = jsonObj[rootnm]['creator'] == null ? '' : jsonObj[rootnm]['creator'];
                var maxnrofinstances = jsonObj[rootnm]['maxNrOfInstances'] == null ? '' : jsonObj[rootnm]['maxNrOfInstances'];
                var maxbytesize = jsonObj[rootnm]['maxByteSize'] == null ? '' : jsonObj[rootnm]['maxByteSize'];
                var maxinstanceage = jsonObj[rootnm]['maxInstanceAge'] == null ? '' : jsonObj[rootnm]['maxInstanceAge'];
                var ontologyref = jsonObj[rootnm]['ontologyRef'] == null ? '' : jsonObj[rootnm]['ontologyRef'];
                var periodicinterval = jsonObj[rootnm]['periodicInterval'] == null ? '' : jsonObj[rootnm]['periodicInterval'];
                var missingdatadetect = jsonObj[rootnm]['missingDataDetect'] == null ? '' : jsonObj[rootnm]['missingDataDetect'];
                var missingdatamaxnr = jsonObj[rootnm]['missingDataMaxNr'] == null ? MISSINGDATAMAXNR : jsonObj[rootnm]['missingDataMaxNr'];
                var missingdatalist = jsonObj[rootnm]['missingDataList'] == null ? '' : jsonObj[rootnm]['missingDataList'];
                var missingdatacurrentnr = jsonObj[rootnm]['missingDataCurrentNr'] == null ? '0' : jsonObj[rootnm]['missingDataCurrentNr'];
                var missingdatadetecttimer = jsonObj[rootnm]['missingDataDetectTimer'] == null ? '' : jsonObj[rootnm]['missingDataDetectTimer'];
                if((periodicinterval > 0) && (missingdatadetect == 'TRUE') && (missingdatadetecttimer == '')) {
                    missingdatadetecttimer = periodicinterval;
                }

                if (expirationtime != '') {
                    cur_d = new Date();
                    //var cur_o = cur_d.getTimezoneOffset()/(-60);
                    //cur_d.setHours(cur_d.getHours() + cur_o);

                    var currenttime = '';
                    //if( cur_o < 10) {
                    //    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}
                    //else {
                    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}

                    if (expirationtime < currenttime) {
                        console.log('Bad Request : expiration is before now');
                        response.setHeader('X-M2M-RSC', '4000');
                        response.status(400).end('<h1>Bad Request : expiration is before now</h1>');
                        return;
                    }
                }

                var cur_d = new Date();
                var msec = (parseInt(cur_d.getMilliseconds(), 10)<10) ? ('00'+cur_d.getMilliseconds()) : ((parseInt(cur_d.getMilliseconds(), 10)<100) ? ('0'+cur_d.getMilliseconds()) : cur_d.getMilliseconds());
                var resourcename = 'ts-' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec + randomValueBase64(4);
                if (request.headers['x-m2m-nm'] != null && request.headers['x-m2m-nm'] != '') {
                    resourcename = request.headers['x-m2m-nm'];
                }
                if (jsonObj[rootnm]['resourceName'] != null && jsonObj[rootnm]['resourceName'] != '') {
                    resourcename = jsonObj[rootnm]['resourceName'];
                }

                create_action(request, response, pool, resourcename, creator, accesscontrolpolicyids, expirationtime, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage, ontologyref, creationtime, level, parentid,
                    periodicinterval, missingdatadetect, missingdatamaxnr, missingdatalist, missingdatacurrentnr, missingdatadetecttimer);
            }
        }
        else { // request.headers.nmtype == 'short'
            // check NP
            if ((jsonObj[rootnm]['ty'] != null) || (jsonObj[rootnm]['ri'] != null) || (jsonObj[rootnm]['pi'] != null) ||
                (jsonObj[rootnm]['ct'] != null) || (jsonObj[rootnm]['lt'] != null) || (jsonObj[rootnm]['st'] != null) ||
                (jsonObj[rootnm]['cni'] != null) || (jsonObj[rootnm]['cbs'] != null)) {
                console.log('Bad Request : NP Tag in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : NP Tag in body\"}' : '<rsp>Bad Request : NP Tag in body</rsp>');
            }
            // check M
            else if (0) {
                console.log('Bad Request : M Tag is none in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : M Tag is none in body\"}' : '<rsp>Bad Request : M Tag is none in body</rsp>');
            }
            else {
                accesscontrolpolicyids = jsonObj[rootnm]['acpi'] == null ? '' : jsonObj[rootnm]['acpi'].toString().replace(/,/g, ' ');
                expirationtime = jsonObj[rootnm]['et'] == null ? '' : jsonObj[rootnm]['et'];
                labels = jsonObj[rootnm]['lbl'] == null ? '' : jsonObj[rootnm]['lbl'].toString().replace(/,/g, ' ');
                announceto = jsonObj[rootnm]['at'] == null ? '' : jsonObj[rootnm]['at'].toString().replace(/,/g, ' ');
                announcedattribute = jsonObj[rootnm]['aa'] == null ? '' : jsonObj[rootnm]['aa'].toString().replace(/,/g, ' ');
                creator = jsonObj[rootnm]['cr'] == null ? '' : jsonObj[rootnm]['cr'];
                maxnrofinstances = jsonObj[rootnm]['mni'] == null ? '' : jsonObj[rootnm]['mni'];
                maxbytesize = jsonObj[rootnm]['mbs'] == null ? '' : jsonObj[rootnm]['mbs'];
                maxinstanceage = jsonObj[rootnm]['mia'] == null ? '' : jsonObj[rootnm]['mia'];
                ontologyref = jsonObj[rootnm]['or'] == null ? '' : jsonObj[rootnm]['or'];
                periodicinterval = jsonObj[rootnm]['pin'] == null ? '' : jsonObj[rootnm]['pin'];
                missingdatadetect = jsonObj[rootnm]['mdd'] == null ? '' : jsonObj[rootnm]['mdd'];
                missingdatamaxnr = jsonObj[rootnm]['mdmn'] == null ? MISSINGDATAMAXNR : jsonObj[rootnm]['mdmn'];
                missingdatalist = jsonObj[rootnm]['mdl'] == null ? '' : jsonObj[rootnm]['mdl'];
                missingdatacurrentnr = jsonObj[rootnm]['mdcn'] == null ? '' : jsonObj[rootnm]['mdcn'];
                missingdatadetecttimer = jsonObj[rootnm]['mddt'] == null ? '' : jsonObj[rootnm]['mddt'];

                if (expirationtime != '') {
                    cur_d = new Date();
                    //cur_o = cur_d.getTimezoneOffset()/(-60);
                    //cur_d.setHours(cur_d.getHours() + cur_o);

                    currenttime = '';
                    //if( cur_o < 10) {
                    //    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}
                    //else {
                    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}

                    if (expirationtime < currenttime) {
                        console.log('Bad Request : expiration is before now');
                        response.setHeader('X-M2M-RSC', '4000');
                        response.status(400).end('<h1>Bad Request : expiration is before now</h1>');
                        return;
                    }
                }

                cur_d = new Date();
                msec = (parseInt(cur_d.getMilliseconds(), 10)<10) ? ('00'+cur_d.getMilliseconds()) : ((parseInt(cur_d.getMilliseconds(), 10)<100) ? ('0'+cur_d.getMilliseconds()) : cur_d.getMilliseconds());
                resourcename = 'ts-' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec + randomValueBase64(4);
                if (request.headers['x-m2m-nm'] != null && request.headers['x-m2m-nm'] != '') {
                    resourcename = request.headers['x-m2m-nm'];
                }
                if (jsonObj[rootnm]['rn'] != null && jsonObj[rootnm]['rn'] != '') {
                    resourcename = jsonObj[rootnm]['rn'];
                }

                create_action(request, response, pool, resourcename, creator, accesscontrolpolicyids, expirationtime, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage, ontologyref, creationtime, level, parentid,
                    periodicinterval, missingdatadetect, missingdatamaxnr, missingdatalist, missingdatacurrentnr, missingdatadetecttimer);
            }
        }
    }
    else {
        console.log('bad request body : different with name type');
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : Body : different with name type\"}' : '<rsp>Bad Request : Body : different with name type</rsp>');
    }
}

exports.create = function(request, response, pool, creator, content_type, level, parentid) {
//    NOPRINT == 'true' ? NOPRINT = 'true' : console.log(request.headers);
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create]');
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] Accept: ' + request.headers.accept);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] locale: ' + request.headers.locale);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] X-M2M-RI: ' + request.headers['x-m2m-ri']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] X-M2M-Origin: ' + request.headers['x-m2m-origin']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] X-M2M-NM: ' + request.headers['x-m2m-nm']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] Content-Type: ' + request.headers['content-type']);

    /*
     if( (request.headers.accept == null) || (request.headers.accept != 'application/onem2m-resource+xml') ) {
     response.status(400).end('<h1>Bad Request : accept</h1>');
     return;
     }

     if( (request.headers['content-type'] == null) || (request.headers['content-type'] != 'application/onem2m-resource+xml') ) {
     response.status(404).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"resource do not exist\"}' : '<rsp>resource do not exist</rsp>');
     return;
     }
     */

    //if( (request.headers['x-m2m-origin'] == null) ) {
    //    response.setHeader('X-M2M-RSC', '4000');
    //    response.status(400).end('<h1>Bad Request : X-M2M-Origin</h1>');
    //    return;
    //}
    //
    //if( (request.headers['x-m2m-ri'] == null) ) {
    //    response.setHeader('X-M2M-RSC', '4000');
    //    response.status(400).end('<h1>Bad Request : X-M2M-RI</h1>');
    //    return;
    //}

    creator = request.headers['x-m2m-origin'];

/*
    if( (request.headers['x-m2m-nm'] == null) ) {
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end('<h1>Bad Request : X-M2M-NM</h1>');
        return;
    }
*/

    if(request.body == "") {
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end('<h1>Bad Request : body is empty</h1>');
        return;
    }

    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.create] ' + request.body);

    var cur_d = new Date();
    //var cur_o = cur_d.getTimezoneOffset()/(-60);
    //cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if((parseInt(cur_d.getMilliseconds(), 10)<10)) {
        msec = ('00'+cur_d.getMilliseconds());
    }
    else if((parseInt(cur_d.getMilliseconds(), 10)<100)) {
        msec = ('0'+cur_d.getMilliseconds());
    }
    else {
        msec = cur_d.getMilliseconds();
    }

    var creationtime = '';
    //if( cur_o < 10) {
    //    creationtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
    //}
    //else {
        creationtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
    //}

    if( content_type.split('+')[1] == 'xml' ) {
        var parser = new xml2js.Parser({explicitArray : false});
        parser.parseString(request.body, function (err, result) {
            if(err) {
                console.log('xml parser error : bad request body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end('<h1>Bad Request : Body</h1>');
            }
            else {
                var jsonString = JSON.stringify(result);
                var jsonObj = JSON.parse(jsonString);

                parse_create_action(request, response, pool, creator, jsonObj, creationtime, level, parentid);
            }
        });
    }
    else if( content_type.split('+')[1] == 'json' ) {
        var jsonObj = {};
        var rootnm = (request.headers.nmtype == 'long') ? ('m2m:timeSeries') : ('m2m:ts');

        if(JSON.parse(request.body.toString())['ts'] != null) {
            (request.headers.nmtype == 'long') ? (jsonObj[rootnm] = JSON.parse(request.body.toString())['ts']) : (jsonObj[rootnm] = JSON.parse(request.body.toString())['ts']);
        }
        else if(JSON.parse(request.body.toString())[rootnm] != null) {
            (request.headers.nmtype == 'long') ? (jsonObj[rootnm] = JSON.parse(request.body.toString())[rootnm]) : (jsonObj[rootnm] = JSON.parse(request.body.toString())[rootnm]);
        }
        else {
            (request.headers.nmtype == 'long') ? (jsonObj[rootnm] = JSON.parse(request.body.toString())) : (jsonObj[rootnm] = JSON.parse(request.body.toString()));
        }

        parse_create_action(request, response, pool, creator, jsonObj, creationtime, level, parentid);
    }
    else {
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end('<h1>Bad Request : do not support content-type</h1>');
    }
};

exports.retrieve = function(request, response, pool, results_ts, status, level, resourceid) {
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log(request.headers);
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.retrieve]');
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.retrieve] Accept: ' + request.headers.accept);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.retrieve] Content-Type: ' + request.headers['content-type']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.retrieve] x-m2m-ri: ' + request.headers['x-m2m-ri']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.retrieve] X-M2M-Origin: ' + request.headers['x-m2m-origin']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.retrieve] locale: ' + request.headers.locale);

    /*    if(request.headers.accept != 'application/onem2m-resource+xml') {
     response.status(400).end('<h1>Bad Request : accept</h1>');
     return;
     }

     if(request.headers['content-type'] != 'application/onem2m-resource+xml') {
     response.status(404).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"resource do not exist\"}' : '<rsp>resource do not exist</rsp>');
     return;
     }
     */

    var node = {};
    var rootnm = (request.headers.nmtype == 'long') ? ('m2m:timeSeries') : ('m2m:ts');
    var listnm = (request.headers.nmtype == 'long') ? ('m2m:URIList') : ('m2m:uril');
    if(request.headers.usebodytype == 'json') {
        results_ts[0].labels = results_ts[0].labels.toString().split(' ');
        results_ts[0].accesscontrolpolicyids = results_ts[0].accesscontrolpolicyids.toString().split(' ');
        results_ts[0].announcedattribute = results_ts[0].announcedattribute.toString().split(' ');
        results_ts[0].announceto = results_ts[0].announceto.toString().split(' ');

        if ((request.query.fu != null) && (request.query.fu == 1)) {
            node[listnm] = [];
            node[listnm].push(results_ts[0].resourceid);

            get_retrieve.request_fu1_json(request, response, pool, node, results_ts[0].resourceid, results_ts[0].resourcetype, results_ts[0].resourcename, status, level, resourceid);
        }
        else if ((request.query.rc == 4) || (request.query.lbl != null) || (request.query.cra != null) || (request.query.crb != null) || (request.query.lim != null)) { // discovery
            node[rootnm] = {};
            node[rootnm][rootnm] = {};
            node[results_ts[0].resourceid] = {};
            node[rootnm][rootnm] = node[results_ts[0].resourceid];
            get_retrieve.addele_ts_json(request, node[results_ts[0].resourceid], results_ts[0]);

            get_retrieve.request_rc4_json(request, response, pool, node, rootnm, results_ts[0].resourceid, results_ts[0].resourcetype, results_ts[0].resourcename, status, level, resourceid);
        }
        else if ((request.query.rc == 0) || (request.query.rc == 2)) {
            response.setHeader('X-M2M-RSC', '2000');
            response.status(status).end('');
        }
        else {
            node[rootnm] = {};
            node[rootnm][rootnm] = {};
            node[results_ts[0].resourceid] = {};
            node[rootnm][rootnm] = node[results_ts[0].resourceid];
            get_retrieve.addele_ts_json(request, node[results_ts[0].resourceid], results_ts[0]);

            get_retrieve.request_json(request, response, pool, node[rootnm], results_ts[0].resourceid, results_ts[0].resourcetype, results_ts[0].resourcename, status);
        }
    }
    else { // request.headers.usebodytype == 'xml'
        if ((request.query.fu != null) && (request.query.fu == 1)) {
            node[0] = xmlbuilder.create(listnm, {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance');

            get_retrieve.request_fu1(request, response, pool, node, results_ts[0].resourceid, results_ts[0].resourcetype, results_ts[0].resourcename, status, level, resourceid);
        }
        else if ((request.query.rc == 4) || (request.query.lbl != null) || (request.query.cra != null) || (request.query.crb != null) || (request.query.lim != null)) { // discovery
            node[results_ts[0].resourceid] = xmlbuilder.create(rootnm, {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance');

            get_retrieve.addele_ts(request, node[results_ts[0].resourceid], results_ts[0]);

            response.setHeader('X-M2M-RSC', '2000');
            get_retrieve.request_rc4(request, response, pool, node, results_ts[0].resourceid, results_ts[0].resourcetype, results_ts[0].resourcename, status, level, resourceid);
        }
        else if ((request.query.rc == 0) || (request.query.rc == 2)) {
            response.setHeader('X-M2M-RSC', '2000');
            response.status(status).end('');
        }
        else {
            node[results_ts[0].resourceid] = xmlbuilder.create(rootnm, {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance');

            get_retrieve.addele_ts(request, node[results_ts[0].resourceid], results_ts[0]);

            get_retrieve.request(request, response, pool, node, results_ts[0].resourceid, results_ts[0].resourcetype, results_ts[0].resourcename, status);
        }
    }
};


function update_action( request, response, pool, expirationtime, accesscontrolpolicyids, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage, ontologyref, statetag, missingdatamaxnr, missingdatadetecttimer, level, resourceid ) {
    // build timeSeries
    var lastmodifiedtime = '';

    var cur_d = new Date();
    //var cur_o = cur_d.getTimezoneOffset()/(-60);
    //cur_d.setHours(cur_d.getHours() + cur_o);

    //if( cur_o < 10) {
    //    lastmodifiedtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
    //}
    //else {
        lastmodifiedtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
    //}

    if(expirationtime == '')
    {
        cur_d.setMonth(cur_d.getMonth() + 1);
        //if( cur_o < 10) {
        //    expirationtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
        //}
        //else {
            expirationtime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
        //}
    }

    if(missingdatadetecttimer == '0') {
        var sql = util.format('update lv%s set lastmodifiedtime = \'%s\', accesscontrolpolicyids = \'%s\', expirationtime = \'%s\', labels = \'%s\', announceto = \'%s\', announcedattribute = \'%s\', maxnrofinstances = \'%s\', maxbytesize = \'%s\', maxinstanceage = \'%s\', ' +
            'ontologyref = \'%s\', statetag = \'%s\', missingdatamaxnr = \'%s\', missingdatadetecttimer = \'%s\', missingdatalist = \'\', missingdatacurrentnr = \'0\' where resourceid = \'%s\'',
            level,
            lastmodifiedtime, accesscontrolpolicyids, expirationtime, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage,
            ontologyref, statetag, missingdatamaxnr, missingdatadetecttimer, resourceid);
    }
    else {
        sql = util.format('update lv%s set lastmodifiedtime = \'%s\', accesscontrolpolicyids = \'%s\', expirationtime = \'%s\', labels = \'%s\', announceto = \'%s\', announcedattribute = \'%s\', maxnrofinstances = \'%s\', maxbytesize = \'%s\', maxinstanceage = \'%s\', ' +
            'ontologyref = \'%s\', statetag = \'%s\', missingdatamaxnr = \'%s\', missingdatadetecttimer = \'%s\' where resourceid = \'%s\'',
            level,
            lastmodifiedtime, accesscontrolpolicyids, expirationtime, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage,
            ontologyref, statetag, missingdatamaxnr, missingdatadetecttimer, resourceid);
    }
    DB.getResult(pool, sql, function (err, results) {
        if(!err) {
            sql = util.format("select * from lv%s where resourceid = \'%s\'", level, resourceid);
            DB.getResult(pool, sql, function (err, results_ts) {
                if(!err) {
                    if (results_ts.length == 1) {
                        subscription.check(request, pool, results_ts, level+1, resourceid, 1);

                        check_TS(level, resourceid, function(rsc, responseBody) {
                            console.log(rsc);
                            console.log(responseBody);
                        });

                        response.setHeader('Content-Location', resourceid);

                        response.setHeader('X-M2M-RSC', '2004');
                        _this.retrieve(request, response, pool, results_ts, 200, level, resourceid);
                    }
                    else {
                        console.log('resource do not exist');
                        response.setHeader('X-M2M-RSC', '4004');
                        response.status(404).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"resource do not exist\"}' : '<rsp>resource do not exist</rsp>');
                    }
                }
                else {
                    console.log('query error: ' + results_ts.code);
                    response.setHeader('X-M2M-RSC', '5000');
                    response.status(500).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"' + results_ts.code + '\"}' : '<rsp>' + results_ts.code + '</rsp>');
                }
            });
        }
        else {
            console.log('query error: ' + results.code);
            response.setHeader('X-M2M-RSC', '5000');
            response.status(500).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"' + results.code + '\"}' : '<rsp>' + results.code + '</rsp>');
        }
    });
}

function parse_update_action(request, response, pool, results_ts, jsonObj, level, resourceid) {
    var rootnm = (request.headers.nmtype == 'long') ? ('m2m:timeSeries') : ('m2m:ts');
    if(jsonObj[rootnm] != null) {
        if(request.headers.nmtype == 'long') {
            // check NP
            if ((jsonObj[rootnm]['resourceName'] != null) || (jsonObj[rootnm]['resourceType'] != null) || (jsonObj[rootnm]['resourceID'] != null) || (jsonObj[rootnm]['parentID'] != null) ||
                (jsonObj[rootnm]['creationTime'] != null) || (jsonObj[rootnm]['lastModifiedTime'] != null) || (jsonObj[rootnm]['stateTag'] != null) || (jsonObj[rootnm]['creator'] != null) ||
                (jsonObj[rootnm]['currentNrOfInstances'] != null) || (jsonObj[rootnm]['currentByteSize'] != null) || (jsonObj[rootnm]['periodicInterval'] != null) || (jsonObj[rootnm]['missingDataDetect'] != null) ||
                (jsonObj[rootnm]['missingDataList'] != null) || (jsonObj[rootnm]['missingDataCurrentNr'] != null)) {
                console.log('Bad Request : Not Present Tag in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : Not Present Tag in body\"}' : '<rsp>Bad Request : Not Present Tag in body</rsp>');
            }
            // check M
            else if (0) {
                console.log('Bad Request : M Tag is none in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : M Tag is none in body\"}' : '<rsp>Bad Request : M Tag is none in body</rsp>');
            }
            else {
                var accesscontrolpolicyids = jsonObj[rootnm]['accessControlPolicyIDs'] == null ? results_ts[0].accesscontrolpolicyids : jsonObj[rootnm]['accessControlPolicyIDs'].toString().replace(/,/g, ' ');
                var expirationtime = jsonObj[rootnm]['expirationTime'] == null ? results_ts[0].expirationtime : jsonObj[rootnm]['expirationTime'];
                var labels = jsonObj[rootnm]['labels'] == null ? results_ts[0].labels : jsonObj[rootnm]['labels'].toString().replace(/,/g, ' ');
                var announceto = jsonObj[rootnm]['announceTo'] == null ? results_ts[0].announceto : jsonObj[rootnm]['announceTo'].toString().replace(/,/g, ' ');
                var announcedattribute = jsonObj[rootnm]['announcedAttribute'] == null ? results_ts[0].announcedattribute : jsonObj[rootnm]['announcedAttribute'].toString().replace(/,/g, ' ');
                var maxnrofinstances = jsonObj[rootnm]['maxNrOfInstances'] == null ? results_ts[0].maxnrofinstances : jsonObj[rootnm]['maxNrOfInstances'];
                var maxbytesize = jsonObj[rootnm]['maxByteSize'] == null ? results_ts[0].maxbytesize : jsonObj[rootnm]['maxByteSize'];
                var maxinstanceage = jsonObj[rootnm]['maxInstanceAge'] == null ? results_ts[0].maxinstanceage : jsonObj[rootnm]['maxInstanceAge'];
                var ontologyref = jsonObj[rootnm]['ontologyRef'] == null ? results_ts[0].ontologyref : jsonObj[rootnm]['ontologyref'];
                var missingdatamaxnr = jsonObj[rootnm]['missingDataMaxNr'] == null ? results_ts[0].missingdatamaxnr : jsonObj[rootnm]['missingDataMaxNr'];
                var missingdatadetecttimer = jsonObj[rootnm]['missingDataDetectTimer'] == null ? results_ts[0].missingdatadetecttimer : jsonObj[rootnm]['missingDataDetectTimer'];

                if (expirationtime != '') {
                    var cur_d = new Date();
                    //var cur_o = cur_d.getTimezoneOffset()/(-60);
                    //cur_d.setHours(cur_d.getHours() + cur_o);

                    var currenttime = '';
                    //if( cur_o < 10) {
                    //    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}
                    //else {
                    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}

                    if (expirationtime < currenttime) {
                        console.log('Bad Request : expiration is before now');
                        response.setHeader('X-M2M-RSC', '4000');
                        response.status(400).end('<h1>Bad Request : expiration is before now</h1>');
                        return;
                    }
                }

                var statetag = parseInt(results_ts[0].statetag, 10) + 1;
                update_action(request, response, pool, expirationtime, accesscontrolpolicyids, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage, ontologyref, statetag, missingdatamaxnr, missingdatadetecttimer, level, resourceid);
            }
        }
        else { // request.headers.nmtype == 'short'
            // check NP
            if ((jsonObj[rootnm]['rn'] != null) || (jsonObj[rootnm]['ty'] != null) || (jsonObj[rootnm]['ri'] != null) || (jsonObj[rootnm]['pi'] != null) ||
                (jsonObj[rootnm]['ct'] != null) || (jsonObj[rootnm]['lt'] != null) || (jsonObj[rootnm]['st'] != null) || (jsonObj[rootnm]['cr'] != null) ||
                (jsonObj[rootnm]['cni'] != null) || (jsonObj[rootnm]['cbs'] != null)) {
                console.log('Bad Request : NP Tag in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : NP Tag in body\"}' : '<rsp>Bad Request : NP Tag in body</rsp>');
            }
            // check M
            else if (0) {
                console.log('Bad Request : M Tag is none in body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : M Tag is none in body\"}' : '<rsp>Bad Request : M Tag is none in body</rsp>');
            }
            else {
                accesscontrolpolicyids = jsonObj[rootnm]['acpi'] == null ? results_ts[0].accesscontrolpolicyids : jsonObj[rootnm]['acpi'].toString().replace(/,/g, ' ');
                expirationtime = jsonObj[rootnm]['et'] == null ? results_ts[0].expirationtime : jsonObj[rootnm]['et'];
                labels = jsonObj[rootnm]['lbl'] == null ? results_ts[0].labels : jsonObj[rootnm]['lbl'].toString().replace(/,/g, ' ');
                announceto = jsonObj[rootnm]['at'] == null ? results_ts[0].announceto : jsonObj[rootnm]['at'].toString().replace(/,/g, ' ');
                announcedattribute = jsonObj[rootnm]['aa'] == null ? results_ts[0].announcedattribute : jsonObj[rootnm]['aa'].toString().replace(/,/g, ' ');
                maxnrofinstances = jsonObj[rootnm]['mni'] == null ? results_ts[0].maxnrofinstances : jsonObj[rootnm]['mni'];
                maxbytesize = jsonObj[rootnm]['mbs'] == null ? results_ts[0].maxbytesize : jsonObj[rootnm]['mbs'];
                maxinstanceage = jsonObj[rootnm]['mia'] == null ? results_ts[0].maxinstanceage : jsonObj[rootnm]['mia'];
                ontologyref = jsonObj[rootnm]['or'] == null ? results_ts[0].ontologyref : jsonObj[rootnm]['or'];
                missingdatamaxnr = jsonObj[rootnm]['mdmn'] == null ? results_ts[0].missingdatamaxnr : jsonObj[rootnm]['mdmn'];
                missingdatadetecttimer = jsonObj[rootnm]['mddt'] == null ? results_ts[0].missingdatadetecttimer : jsonObj[rootnm]['mddt'];

                if (expirationtime != '') {
                    cur_d = new Date();
                    //cur_o = cur_d.getTimezoneOffset()/(-60);
                    //cur_d.setHours(cur_d.getHours() + cur_o);

                    currenttime = '';
                    //if( cur_o < 10) {
                    //    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}
                    //else {
                    currenttime = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                    //}

                    if (expirationtime < currenttime) {
                        console.log('Bad Request : expiration is before now');
                        response.setHeader('X-M2M-RSC', '4000');
                        response.status(400).end('<h1>Bad Request : expiration is before now</h1>');
                        return;
                    }
                }

                statetag = parseInt(results_ts[0].statetag, 10) + 1;

                update_action(request, response, pool, expirationtime, accesscontrolpolicyids, labels, announceto, announcedattribute, maxnrofinstances, maxbytesize, maxinstanceage, ontologyref, statetag, missingdatamaxnr, missingdatadetecttimer, level, resourceid);
            }
        }
    }
    else {
        console.log('bad request body : different with name type');
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : Body : different with name type\"}' : '<rsp>Bad Request : Body : different with name type</rsp>');
    }
}

exports.update = function(request, response, pool, results_ts, content_type, level, resourceid) {
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log(request.headers);
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update]');
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update] Accept: ' + request.headers.accept);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update] locale: ' + request.headers.locale);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update] X-M2M-RI: ' + request.headers['x-m2m-ri']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update] X-M2M-Origin: ' + request.headers['x-m2m-origin']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update] Content-Type: ' + request.headers['content-type']);

    /*
     if( (request.headers.accept == null) || (request.headers.accept != 'application/onem2m-resource+xml') ) {
     response.setHeader('X-M2M-RSC', '4000');
     response.status(400).end('<h1>Bad Request : accept</h1>');
     return;
     }

     if( (request.headers['content-type'] == null) || (request.headers['content-type'] != 'application/onem2m-resource+xml') ) {
     response.setHeader('X-M2M-RSC', '4000');
     response.status(404).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"resource do not exist\"}' : '<rsp>resource do not exist</rsp>');
     return;
     }
     */

    //if( (request.headers['x-m2m-origin'] == null) ) {
    //    response.setHeader('X-M2M-RSC', '4000');
    //    response.status(400).end('<h1>Bad Request : X-M2M-Origin</h1>');
    //    return;
    //}
    //
    //if( (request.headers['x-m2m-ri'] == null) ) {
    //    response.setHeader('X-M2M-RSC', '4000');
    //    response.status(400).end('<h1>Bad Request : X-M2M-RI</h1>');
    //    return;
    //}

    if(request.body == "") {
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end('<h1>Bad Request : body is empty</h1>');
        return;
    }

    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.update] ' + request.body);

    if( content_type.split('+')[1] == 'xml' ) {
        var parser = new xml2js.Parser({explicitArray : false});
        parser.parseString(request.body, function (err, result) {
            if(err) {
                console.log('bad request body');
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end('<h1>Bad Request : Body</h1>');
            }
            else {
                var jsonString = JSON.stringify(result);
                var jsonObj = JSON.parse(jsonString);

                parse_update_action(request, response, pool, results_ts, jsonObj, level, resourceid);
            }
        });
    }
    else if( content_type.split('+')[1] == 'json' ) {
        var jsonObj = {};
        var rootnm = (request.headers.nmtype == 'long') ? ('m2m:timeSeries') : ('m2m:ts');

        if(JSON.parse(request.body.toString())['ts'] != null) {
            (request.headers.nmtype == 'long') ? (jsonObj[rootnm] = JSON.parse(request.body.toString())['ts']) : (jsonObj[rootnm] = JSON.parse(request.body.toString())['ts']);
        }
        else if(JSON.parse(request.body.toString())[rootnm] != null) {
            (request.headers.nmtype == 'long') ? (jsonObj[rootnm] = JSON.parse(request.body.toString())[rootnm]) : (jsonObj[rootnm] = JSON.parse(request.body.toString())[rootnm]);
        }
        else {
            (request.headers.nmtype == 'long') ? (jsonObj[rootnm] = JSON.parse(request.body.toString())) : (jsonObj[rootnm] = JSON.parse(request.body.toString()));
        }

        parse_update_action(request, response, pool, results_ts, jsonObj, level, resourceid);
    }
    else {
        response.setHeader('X-M2M-RSC', '4000');
        response.status(400).end('<h1>Bad Request : do not support content-type</h1>');
    }
};

exports.delete = function(request, response, pool, results_ts, status, level, resourceid) {
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log(request.headers);
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.delete]');
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.delete] Accept: ' + request.headers.accept);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.delete] Content-Type: ' + request.headers['content-type']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.delete] x-m2m-ri: ' + request.headers['x-m2m-ri']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.delete] X-M2M-Origin: ' + request.headers['x-m2m-origin']);
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[TS.delete] locale: ' + request.headers.locale);

    /*    if(request.headers.accept != 'application/onem2m-resource+xml') {
     response.status(400).end('<h1>Bad Request : accept</h1>');
     return;
     }

     if(request.headers['content-type'] != 'application/onem2m-resource+xml') {
     response.status(404).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"resource do not exist\"}' : '<rsp>resource do not exist</rsp>');
     return;
     }
     */

    delete_TS(level, resourceid, function(rsc, responseBody) {
        console.log(rsc);
        console.log(responseBody);
    });

    delete_delete.request(request, response, pool, results_ts, status, level, resourceid);
};


/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file Main code of Mobius Yellow. Role of flow router
 * @copyright KETI Korea 2015, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var fs = require('fs');
var http = require('http');
var mysql = require('mysql');
var express = require('express');
var bodyParser = require('body-parser');
var util = require('util');
var xml2js = require('xml2js');
var ip = require('ip');
var js2xmlparser = require("js2xmlparser");

global.defaultnmtype = 'short';
global.defaultbodytype = 'json';

global.usecbtype = 'in';
global.usecbname = 'mobius2';
global.usecbhost = '127.0.0.1';
global.usecbport = '8080';
global.usecbcseid = '0.2.481.1.1.1.1';

global.usecsebase = 'mobius';
global.usecseid = '0.2.481.1.1.1.1';
global.usecseport = '7579';
global.usedbhost = '';
global.usedbpass = '';
global.usemqttproxy = 'localhost';
global.usemqttproxyport = '9726';

global.NOPRINT = 'true';
global.ONCE = 'true';

var DB = require('./db_action');

// ������ �����մϴ�.
var app = express();

var pool = null;

// This is an async file read
fs.readFile('conf.json', 'utf-8', function (err, data) {
    if (err) {
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log("FATAL An error occurred trying to read in the file: " + err);
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log("error : set to default for configuration")
    }
    else {
        var conf = JSON.parse(data)['m2m:conf'];

        usecbtype = conf['cbtype'];
        defaultnmtype = conf['nmtype'];
        defaultbodytype = conf['bodytype'];

        usecseid = conf['in-cse']['cseid'];
        usecsebase = conf['in-cse']['csebase'];
        usecseport = conf['in-cse']['cseport'];
        usedbhost = conf['in-cse']['dbhost'];
        usedbpass = conf['in-cse']['dbpass'];
        usemqttproxy = conf['in-cse']['mqttproxy'];
        usemqttproxyport = conf['in-cse']['mqttproxyport'];

        usecbhost = conf['mn-cse']['cbhost'];
        usecbport = conf['mn-cse']['cbport'];
        usecbname = conf['mn-cse']['cbname'];
        usecbcseid = conf['mn-cse']['cbcseid'];

        app.use(bodyParser.urlencoded({ extended: true }));
        app.use(bodyParser.json({limit: '1mb', type: 'application/*+json' }));
        app.use(bodyParser.text({limit: '1mb', type: 'application/*+xml' }));

        http.globalAgent.maxSockets = 1000000;

        pool = DB.connect(usedbhost, 3306, 'root', usedbpass);

        http.createServer(app).listen({port: 7586, agent: false}, function () {
            //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('server running at ' + usecseport + ' port');
            console.log('ts_missing agent server (' + ip.address() + ') running at 7586 port');

            // Searching TS with missingDetect. if it is TRUE, restart missingDataDetectTimer
            init_TS(function(rsc, responseBody) {
                console.log(rsc);
                console.log(responseBody);
            });
        });
    }
});

function init_TS(callback) {
    var resourceid = '/missingDataDetect';
    var options = {
        hostname: 'localhost',
        port: '7586',
        path: resourceid,
        method: 'post',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': '12345',
            'Accept': 'application/xml',
            'X-M2M-Origin': 'Origin',
            'nmtype': 'long',
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var reqBodyString = '';
    var jsonObj = {};
    jsonObj.resourceid = 'all';
    jsonObj.level = '1';
    reqBodyString = js2xmlparser('ts', JSON.stringify(jsonObj));

    var responseBody = '';
    var req = http.request(options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            responseBody += chunk;
        });

        res.on('end', function() {
            callback(res.headers['x-m2m-rsc'], responseBody);
        });
    });

    req.on('error', function (e) {
        if(e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    // write data to request body
    req.write(reqBodyString);
    req.end();
}


function search_TS(request, response, callback) {
    var resourceid = '/' + usecsebase + '?fu=1&rty=25';
    var options = {
        hostname: 'localhost',
        port: '7579',
        path: resourceid,
        method: 'get',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': '12345',
            'Accept': 'application/xml',
            'X-M2M-Origin': 'Origin',
            'nmtype': 'long'
        }
    };

    var responseBody = '';
    var req = http.request(options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            responseBody += chunk;
        });

        res.on('end', function() {
            callback(request, response, res.headers['x-m2m-rsc'], responseBody);
        });
    });

    req.on('error', function (e) {
        if(e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    // write data to request body
    req.write('');
    req.end();
}


//var xmlParser = bodyParser.text({ limit: '1mb', type: 'application/onem2m-resource+xml;application/xml;application/json;application/vnd.onem2m-prsp+xml;application/vnd.onem2m-prsp+json' });
var xmlParser = bodyParser.text({ limit: '1mb', type: '*/*' });


var ts_timer = {};
var ts_timer_id = {};

var missing_detect_check = function(pool, periodicinterval, missingdatadetect, missingdatadetecttimer, currentnrofinstances, level, resourceid, callback) {
    var rsc = {};
    rsc.status = 2000;
    if((periodicinterval != null && periodicinterval != '' && periodicinterval != '0') && (missingdatadetect != null && missingdatadetect == 'TRUE') && missingdatadetecttimer != '0') {
        if(ts_timer[resourceid] == null) {
            ts_timer[resourceid] = new process.EventEmitter();
            ts_timer[resourceid].on(resourceid, function () {
                var sql = util.format("select currentnrofinstances, missingdatacurrentnr, missingdatamaxnr, missingdatalist, resourceid from lv%s where resourceid = \'%s\'", level, resourceid);
                DB.getResult(pool, sql, function (err, results) {
                    if (results.length == 1) {
                        console.log(results[0].resourceid);
                        var new_currentnrofinstances = results[0]['currentnrofinstances'];
                        if (parseInt(new_currentnrofinstances, 10) == parseInt(currentnrofinstances, 10)) {
                            if (parseInt(results[0].missingdatacurrentnr, 10) <= parseInt(results[0].missingdatamaxnr, 10)) {
                                var cur_d = new Date();
                                var timestamp = cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '');
                                var missingdatalist = timestamp + ' ' + results[0].missingdatalist;
                                var missingdatacurrentnr = (parseInt(results[0].missingdatacurrentnr, 10) + 1).toString();
                                console.log(missingdatacurrentnr, missingdatalist);
                                sql = util.format("update lv%s set missingdatacurrentnr = \'%s\', missingdatalist = \'%s\' where resourceid = \'%s\'", level, missingdatacurrentnr, missingdatalist, resourceid);
                                DB.getResult(pool, sql, function (err, results) {
                                    if (!err) {
                                    }
                                    else {
                                        console.log('query error: ' + results.code);
                                    }
                                });
                            }
                        }
                        currentnrofinstances = new_currentnrofinstances;
                    }
                });
            });
        }

        if(ts_timer_id[resourceid] == null) {
            ts_timer_id[resourceid] = setInterval(function () {
                ts_timer[resourceid].emit(resourceid);
            }, (parseInt(missingdatadetecttimer) * 1000));
            rsc.status = 2000;
            rsc.resourceid = resourceid;
            callback(rsc);
        }
        else if(ts_timer_id[resourceid] != null) {
            clearInterval(ts_timer_id[resourceid]);
            ts_timer_id[resourceid] = setInterval(function () {
                ts_timer[resourceid].emit(resourceid);
            }, (parseInt(missingdatadetecttimer)*1000));
            rsc.status = 2000;
            rsc.resourceid = resourceid;
            callback(rsc);
        }
        else {
            rsc.status = 2001;
            rsc.resourceid = resourceid;
            callback(rsc);
        }
    }
    else {
        if(ts_timer_id[resourceid] != null) {
            clearInterval(ts_timer_id[resourceid]);
            delete ts_timer_id[resourceid];
        }

        rsc.status = 2001;
        rsc.resourceid = resourceid;
        callback(rsc);
    }
};


//
app.post('/:resourcename0', xmlParser, function(request, response, next) {
    if(request.params.resourcename0.toLowerCase() == 'missingdatadetect') {
        var parser = new xml2js.Parser({explicitArray: false});
        parser.parseString(request.body.toString(), function (err, result) {
            if (err) {
                NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[retrieve_CSEBase parsing error]');
            }
            else {
                var jsonString = JSON.stringify(result);
                var jsonObj = JSON.parse(jsonString);
                if(jsonObj.ts.resourceid == 'all') {
                    search_TS(request, response, function (request, response, rsc, responseBody) {
                        console.log(rsc);
                        console.log(responseBody);

                        var parser = new xml2js.Parser({explicitArray: false});
                        parser.parseString(responseBody.toString(), function (err, result) {
                            if (err) {
                                NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[retrieve_CSEBase parsing error]');
                            }
                            else {
                                var jsonString = JSON.stringify(result);
                                var jsonObj = JSON.parse(jsonString);
                                if(jsonObj['m2m:URIList']['_'] == null) {
                                    var ts_resourceid = [];
                                }
                                else {
                                    ts_resourceid = jsonObj['m2m:URIList']['_'].toString().split(' ');
                                }

                                if (ts_resourceid.length > 1) {
                                    for (var t = 0; t < ts_resourceid.length - 1; t++) {
                                        var level = ts_resourceid[t].split('/').length - 2;
                                        var sql = util.format("select * from lv%s where resourceid = \'%s\'", level, ts_resourceid[t]);
                                        DB.getResult(pool, sql, function (err, results_ts) {
                                            if (!err) {
                                                if (results_ts.length == 1) {
                                                    missing_detect_check(pool, results_ts[0].periodicinterval, results_ts[0].missingdatadetect, results_ts[0].missingdatadetecttimer, results_ts[0].currentnrofinstances, level, results_ts[0].resourceid, function (rsc) {
                                                        console.log(rsc);
                                                    });
                                                }
                                            }
                                        });
                                    }
                                    response.setHeader('X-M2M-RSC', '2000');
                                    var ts = {};
                                    ts.status = '2000';
                                    ts.resourceid = jsonObj['m2m:URIList']['_'];
                                    response.status(200).end(JSON.stringify(ts));
                                }
                            }
                        });
                    });
                }
                else {
                    var sql = util.format("select * from lv%s where resourceid = \'%s\'", jsonObj.ts.level, jsonObj.ts.resourceid);
                    DB.getResult(pool, sql, function (err, results_ts) {
                        if (!err) {
                            if (results_ts.length == 1) {
                                missing_detect_check(pool, results_ts[0].periodicinterval, results_ts[0].missingdatadetect, results_ts[0].missingdatadetecttimer, results_ts[0].currentnrofinstances, jsonObj.ts.level, results_ts[0].resourceid, function (rsc) {
                                    console.log(rsc.status + ' - ' + rsc.resourceid);
                                    response.setHeader('X-M2M-RSC', '2000');
                                    response.status(200).end(JSON.stringify(rsc));
                                });
                            }
                        }
                    });
                }
            }
        });
    }
});


app.delete('/:resourcename0', xmlParser, function(request, response, next) {
    if(request.params.resourcename0.toLowerCase() == 'missingdatadetect') {
        var parser = new xml2js.Parser({explicitArray: false});
        parser.parseString(request.body.toString(), function (err, result) {
            if (err) {
                NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[retrieve_CSEBase parsing error]');
            }
            else {
                var jsonString = JSON.stringify(result);
                var jsonObj = JSON.parse(jsonString);
                var resourceid = jsonObj.ts.resourceid;
                if(ts_timer[resourceid] != null) {
                    ts_timer[resourceid].removeAllListeners(resourceid);
                    delete ts_timer[resourceid];
                }

                if(ts_timer_id[resourceid] != null) {
                    clearInterval(ts_timer_id[resourceid]);
                    delete ts_timer_id[resourceid];
                }

                var rsc = {};
                rsc.status = 2000;
                rsc.resourceid = resourceid;
                console.log(rsc.status + ' - ' + rsc.resourceid);
                response.setHeader('X-M2M-RSC', '2000');
                response.status(200).end(JSON.stringify(rsc));
            }
        });
    }
});

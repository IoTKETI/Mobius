/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * @copyright KETI Korea 2015, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var fs = require('fs');
var http = require('http');
var mysql = require('mysql');
var express = require('express');
var bodyParser = require('body-parser');
var mqtt = require('mqtt');
var morgan = require('morgan');
var util = require('util');
var xml2js = require('xml2js');
const crypto = require('crypto');

var url = require('url');
var xmlbuilder = require('xmlbuilder');
var js2xmlparser = require("js2xmlparser");

global.resp_mqtt_client_arr = [];
global.req_mqtt_client_arr = [];
global.req_mqtt_ri_arr = [];

function response_mqtt(mqtt_client, resp_cseid, rsc, to, fr, ri, inpc) {
    var rsp_message = {};
    rsp_message.rsc = rsc;
    rsp_message.to = to;
    rsp_message.fr = fr;
    rsp_message.ri = ri;
    rsp_message.pc = inpc;

    rsp_message['@'] = {
        "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
    };

    var xmlString = js2xmlparser("m2m:rsp", rsp_message);

    var rsp_topic = util.format('/oneM2M/resp/%s/%s', resp_cseid, usecseid.replace('/', ':'));

    mqtt_client.publish(rsp_topic, xmlString);
}

function forward_mqtt(forward_cseid, op, to, fr, ri, ty, nm, inpc) {
    var forward_message = {};
    forward_message.op = op;
    forward_message.to = to;
    forward_message.fr = fr;
    forward_message.ri = ri;
    forward_message.ty = ty;
    forward_message.nm = nm;
    forward_message.pc = inpc;

    forward_message['@'] = {
        "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
    };

    var xmlString = js2xmlparser("m2m:rqp", forward_message);

    var forward_topic = util.format('/oneM2M/req/%s/%s', usecseid.replace('/', ':'), forward_cseid);

    for(var i = 0; i < mqtt_client_arr.length; i++) {
        mqtt_client_arr[i].publish(forward_topic, xmlString);
    }
}

exports.resp_connect = function(serverip, pool) {
    //var mqtt_client  = mqtt.connect('mqtt://test.mosquitto.org');
//var mqtt_client  = mqtt.connect('mqtt://203.253.128.150');
//var mqtt_client  = mqtt.connect( 'mqtt://localhost',{ protocolId: 'MQIsdp', protocolVersion: 3 } );
    var resp_topic = util.format('/oneM2M/resp/%s/#', usecseid.replace('/', ':'));

    var mqtt_client = mqtt.connect('mqtt://' + serverip);

    mqtt_client.on('connect', function () {
        mqtt_client.subscribe(resp_topic);

        resp_mqtt_client_arr.push(mqtt_client);

/* for test
        req_topic = req_topic.replace('+', usecseid);
        mqtt_client.publish(req_topic, 'request Hello mqtt');

        resp_topic = resp_topic.replace('+', usecseid);
        mqtt_client.publish(resp_topic, 'response Hello mqtt');
        */
    });

    mqtt_client.on('message', function (topic, message) {
        var topic_arr = topic.split("/");
        if(topic_arr[5] != null) {
            var bodytype = (topic_arr[5] == 'xml') ? topic_arr[5] : ((topic_arr[5] == 'json') ? topic_arr[5] : 'json');
        }

        if(topic_arr[1] == 'oneM2M' && topic_arr[2] == 'resp' && topic_arr[3].replace(':', '/') == usecseid) {
            if(bodytype == 'xml') {
                parser = new xml2js.Parser({explicitArray: false});
                parser.parseString(message.toString(), function (err, result) {
                    if (err) {
                        console.log('[pxymqtt-resp xml2js parser error]');
                    }
                    else {
                        var jsonObj = result;

                        if (jsonObj['m2m:rsp'] != null) {
                            var op = (jsonObj['m2m:rsp']['op'] == null) ? '' : jsonObj['m2m:rsp']['op'];
                            var to = (jsonObj['m2m:rsp']['to'] == null) ? '' : jsonObj['m2m:rsp']['to'];
                            var fr = (jsonObj['m2m:rsp']['fr'] == null) ? '' : jsonObj['m2m:rsp']['fr'];
                            var ri = (jsonObj['m2m:rsp']['ri'] == null) ? '' : jsonObj['m2m:rsp']['ri'];
                            var ty = (jsonObj['m2m:rsp']['ty'] == null) ? '' : jsonObj['m2m:rsp']['ty'];
                            var nm = (jsonObj['m2m:rsp']['nm'] == null) ? '' : jsonObj['m2m:rsp']['nm'];
                            var pc = (jsonObj['m2m:rsp']['pc'] == null) ? '' : jsonObj['m2m:rsp']['pc'];

                            for (var i = 0; i < req_mqtt_ri_arr.length; i++) {
                                if (req_mqtt_ri_arr[i] == jsonObj['m2m:rsp'].ri) {
                                    console.log(jsonObj['m2m:rsp'].rsc);

                                    if (to == usecseid) {
                                        // nothing
                                        NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[pxymqtt-resp]' + message);
                                    }
                                    else {
                                        if (usecbtype == 'mn') {
                                            forward_mqtt(to, op, to, fr, ri, ty, nm, pc);
                                        }
                                        else {
                                            response_mqtt(mqtt_client, topic_arr[4], 4004, fr, usecseid, ri, '<h1>MN-CSE is not, csebase do not exist</h1>');
                                        }
                                    }

                                    req_mqtt_ri_arr.slice(i, 1);
                                    break;
                                }
                            }
                        }
                        else {
                            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[pxymqtt-resp] message is not resp');
                            response_mqtt(mqtt_client, topic_arr[4], 4000, fr, usecseid, ri, '<h1>fail to parsing mqtt message</h1>');
                        }
                    }
                });
            }
            else { // 'json'
                var jsonObj = JSON.parse(message.toString());

                if (jsonObj['m2m:rsp'] != null) {
                    for (var i = 0; i < req_mqtt_ri_arr.length; i++) {
                        if (req_mqtt_ri_arr[i] == jsonObj['m2m:rsp'].ri) {
                            console.log(jsonObj['m2m:rsp'].rsc);
                            req_mqtt_ri_arr.slice(i, 1);
                            break;
                        }
                    }
                }
            }
        }
        else {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('topic is not supported');
        }
    });
};


exports.req_connect = function(serverip, pool, topic_prefix) {
    //var mqtt_client  = mqtt.connect('mqtt://test.mosquitto.org');
//var mqtt_client  = mqtt.connect('mqtt://203.253.128.150');
//var mqtt_client  = mqtt.connect( 'mqtt://localhost',{ protocolId: 'MQIsdp', protocolVersion: 3 } );
    var req_topic = util.format('/oneM2M/req/+/%s%s/#', usecseid.replace('/', ':'), topic_prefix);

    var mqtt_client = mqtt.connect('mqtt://' + serverip);

    mqtt_client.on('connect', function () {
        mqtt_client.subscribe(req_topic);

        req_mqtt_client_arr.push(mqtt_client);

        /* for test
         req_topic = req_topic.replace('+', usecseid);
         mqtt_client.publish(req_topic, 'request Hello mqtt');

         resp_topic = resp_topic.replace('+', usecseid);
         mqtt_client.publish(resp_topic, 'response Hello mqtt');
         */
    });

    mqtt_client.on('message', function (topic, message) {
        // message is Buffer
        //NOPRINT == 'true' ? NOPRINT = 'true' : console.log(topic);
        var topic_arr = topic.split("/");
        //NOPRINT == 'true' ? NOPRINT = 'true' : console.log(JSON.stringify(topic_arr));

        if(topic_arr[5] != null) {
            var bodytype = (topic_arr[5] == 'xml') ? topic_arr[5] : ((topic_arr[5] == 'json') ? topic_arr[5] : 'json');
        }

        if(topic_arr[1] == 'oneM2M' && topic_arr[2] == 'req' && topic_arr[4].replace(':', '/') == usecseid) {

            if(bodytype == xml) {
                var parser = new xml2js.Parser({explicitArray: false});
                parser.parseString(message, function (err, result) {
                    if (err) {
                        console.log('[pxymqtt-rqp xml2js parser error]');
                    }
                    else {
                        var jsonString = JSON.stringify(result);
                        var jsonObj = JSON.parse(jsonString);

                        if (jsonObj['m2m:rqp'] != null) {
                            var op = (jsonObj['m2m:rqp']['op'] == null) ? '' : jsonObj['m2m:rqp']['op'];
                            var to = (jsonObj['m2m:rqp']['to'] == null) ? '' : jsonObj['m2m:rqp']['to'];
                            var fr = (jsonObj['m2m:rqp']['fr'] == null) ? '' : jsonObj['m2m:rqp']['fr'];
                            var ri = (jsonObj['m2m:rqp']['ri'] == null) ? '' : jsonObj['m2m:rqp']['ri'];
                            var ty = (jsonObj['m2m:rqp']['ty'] == null) ? '' : jsonObj['m2m:rqp']['ty'];
                            var nm = (jsonObj['m2m:rqp']['nm'] == null) ? '' : jsonObj['m2m:rqp']['nm'];
                            var pc = (jsonObj['m2m:rqp']['pc'] == null) ? '' : jsonObj['m2m:rqp']['pc'];

                            if (to == usecsebase) {
                                mqtt_binding(mqtt_client, topic_arr[3], op, to, fr, ri, ty, nm, pc, pool);
                            }
                            else {
                                if (usecbtype == 'mn') {
                                    mqtt_forwarding(mqtt_client, topic_arr[3], op, to, fr, ri, ty, nm, pc, pool);
                                }
                                else {
                                    response_mqtt(mqtt_client, topic_arr[3], 4004, fr, usecseid, ri, '<h1>MN-CSE is not, csebase do not exist</h1>');
                                }
                            }
                        }
                        else {
                            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[pxymqtt-rqp] message is not rqp');
                            response_mqtt(mqtt_client, topic_arr[3], 4000, fr, usecseid, ri, '<h1>fail to parsing mqtt message</h1>');
                        }
                    }
                });
            }
        }
        else {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('topic is not supported');
        }
    });
};


function mqtt_binding(mqtt_client, resp_cseid, op, to, fr, ri, ty, nm, pc, pool) {
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[mqtt_binding]');

    var content_type = 'application/vnd.onem2m-res+xml';

    switch (op) {
        case '1':
            op = 'post';
            content_type += ('; ty=' + ty);
            break;
        case '2':
            op = 'get';
            break;
        case '3':
            op = 'put';
            break;
        case '4':
            op = 'delete';
            break;
    }

    if( op == 'post' || op == 'put') {
        pc['@'] = {
            "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
        };

        switch (ty) {
            case '16':
                pc = js2xmlparser('m2m:csr', JSON.stringify(pc.csr));
                break;
            case '2':
                pc = js2xmlparser('m2m:ae', JSON.stringify(pc.ae));
                break;
            case '3':
                pc = js2xmlparser('m2m:con', JSON.stringify(pc.cnt));
                break;
            case '4':
                pc = js2xmlparser('m2m:cin', JSON.stringify(pc.cin));
                break;
            case '23':
                pc = js2xmlparser('m2m:sup', JSON.stringify(pc.sub));
                break;
        }
    }

    var options = {
        hostname: 'localhost',
        port: '7579',
        path: to,
        method: op,
        headers: {
            'locale': 'ko',
            'X-M2M-RI': ri,
            'Accept': 'application/xml',
            'X-M2M-Origin': fr,
            'X-M2M-NM': nm,
            'Content-Type': content_type
        }
    };

    var req = http.request(options, function (res) {
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[mqtt_binding response : ' + res.statusCode);
        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            var parser = new xml2js.Parser({explicitArray : false});
            parser.parseString(chunk, function (err, result) {
                if (err) {
                    console.log('[mqtt_binding parser error]');
                }
                else {
                    var jsonString = JSON.stringify(result);
                    jsonString = jsonString.replace('\"$\":{\"xmlns:m2m\":\"http://www.onem2m.org/xml/protocols\",\"xmlns:xsi\":\"http://www.w3.org/2001/XMLSchema-instance\"},', "");
                    var jsonObj = JSON.parse(jsonString);

                    //jsonObj["@"] = {
                    //    "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
                    //    "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
                    //};

                    response_mqtt(mqtt_client, resp_cseid, res.headers['x-m2m-rsc'], fr, usecseid, ri, jsonObj);
                }
            });
        });
    });

    req.on('error', function (e) {
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log('problem with request: ' + e.message);
    });

    // write data to request body
    if ((op == 'get') || (op == 'delete')) {
        req.write('');
    }
    else {
        req.write(pc);
    }
    req.end();
}


function mqtt_forwarding(mqtt_client, resp_cseid, op, to, fr, ri, ty, nm, pc, pool) {
    NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[mqtt_forwarding]');

    var path = util.format('/%s/%s', usecsebase, to);
    var sql = util.format("select * from lv1 where path = \'%s\'", path);
    DB.getResult(pool, sql, function (err, results) {
        if(!err) {
            if (results.length == 1) {
                if(results[0].resourcetype == 16) {
                    var forward_cseid = results[0].cseid;
                }
                else if(results[0].resourcetype == 2) {
                    forward_cseid = results[0].aeid;
                }
                forward_mqtt(forward_cseid, op, to, fr, ri, ty, nm, pc);
            }
            else {
                NOPRINT == 'true' ? NOPRINT = 'true' : console.log('csebase forwarding do not exist');
                response_mqtt(mqtt_client, resp_cseid, 4004, fr, usecseid, ri, '<h1>csebase forwarding do not exist</h1>');
            }
        }
        else {
            console.log('query error: ' + results.code);
        }
    });
}

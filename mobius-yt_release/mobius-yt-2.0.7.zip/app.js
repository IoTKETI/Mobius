/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file Main code of Mobius Yellow. Role of flow router
 * @copyright KETI Korea 2015, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var fs = require('fs');
var http = require('http');
var mysql = require('mysql');
var express = require('express');
var bodyParser = require('body-parser');
var morgan = require('morgan');
var util = require('util');
var xml2js = require('xml2js');
var url = require('url');
var xmlbuilder = require('xmlbuilder');
var js2xmlparser = require("js2xmlparser");
var ip = require('ip');
const crypto = require('crypto');
var FileStreamRotator = require('file-stream-rotator');
var merge = require('merge');
var https = require('https');

global.defaultnmtype = 'short';
global.defaultbodytype = 'json';

global.usecbtype = 'in';
global.usecbname = 'mobius2';
global.usecbhost = '127.0.0.1';
global.usecbhostport = '8080';
global.usecbcseid = '0.2.481.1.1.1.1';

global.usecsebase = 'mobius';
global.usecseid = '0.2.481.1.1.1.1';
global.usecsebaseport = '7579';

global.usedbname = 'mysql';
//global.usedbname = 'mongodb';

global.usedbhost = '';
global.usedbpass = '';
global.usemqttproxy = 'localhost';
global.usemqttproxyport = '9726';

global.NOPRINT = 'true';
global.ONCE = 'true';

global.conf_filename = 'conf.json';

var cb = require('./mobius/cb');
var responder = require('./mobius/responder');
var resource = require('./mobius/resource');
var security = require('./mobius/security');

var db = require('./mobius/db_action');

var cluster = require('cluster');
var os = require('os');

var cpuCount = os.cpus().length;


// ������ �����մϴ�.
var app = express();

global.M2M_SP_ID = '//mobius-yt.keti.re.kr';

global.randomValueBase64 = function(len) {
    return crypto.randomBytes(Math.ceil(len * 3 / 4))
        .toString('base64')   // convert to base64 format
        .slice(0, len)        // return required number of characters
        .replace(/\+/g, '0')  // replace '+' with '0'
        .replace(/\//g, '0'); // replace '/' with '0'
};

global.randomIntInc = function(low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
};

global.randomValue = function(qty) {
    return crypto.randomBytes(qty).toString(2);
};

var logDirectory = __dirname + '/log';

// ensure log directory exists
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

// create a rotating write stream
var accessLogStream = FileStreamRotator.getStream({
    date_format: 'YYYYMMDD',
    filename: logDirectory + '/access-%DATE%.log',
    frequency: 'daily',
    verbose: false
});

// setup the logger
app.use( morgan('combined', {stream: accessLogStream}));
//app.use(morgan('short', {stream: accessLogStream}));

var worker = [];

if(cluster.isMaster) {
    cluster.on('death', function(worker) {
        console.log('worker' + worker.pid + ' died --> start again');
        cluster.fork();
    });

    // This is an async file read
    fs.readFile(conf_filename, 'utf-8', function (err, data) {
        if (err) {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log("FATAL An error occurred trying to read in the file: " + err);
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log("error : set to default for configuration")
        }
        else {
            var conf = JSON.parse(data)['m2m:conf'];

            usecbtype = 'in';
            defaultnmtype = 'short';

            usecsebase = conf['csebase'];
            usecsebaseport = conf['csebaseport'];
            usedbhost = conf['dbhost'];
            usedbpass = conf['dbpass'];
            usemqttproxy = conf['mqttproxy'];
            usemqttproxyport = conf['mqttproxyport'];

            db.connect(usedbhost, 3306, 'root', usedbpass, function (rsc) {
                if(rsc == '1') {
                    cb.create(function(rsp) {
                        console.log(JSON.stringify(rsp));

                        console.log('CPU Count:', cpuCount);
                        for(var i = 0; i < cpuCount; i++) {
                            worker[i] = cluster.fork();
                        }

                        require('./pxymqtt');
                        //require('./mobius/ts_agent');
                    });
                }
            });
        }
    });
}
else {
    // This is an async file read
    fs.readFile(conf_filename, 'utf-8', function (err, data) {
        if (err) {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log("FATAL An error occurred trying to read in the file: " + err);
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log("error : set to default for configuration")
        }
        else {
            var conf = JSON.parse(data)['m2m:conf'];

            usecbtype = 'in';
            defaultnmtype = 'short';

            usecsebase = conf['csebase'];
            usecsebaseport = conf['csebaseport'];
            usedbhost = conf['dbhost'];
            usedbpass = conf['dbpass'];
            usemqttproxy = conf['mqttproxy'];
            usemqttproxyport = conf['mqttproxyport'];

            app.use(bodyParser.urlencoded({ extended: true }));
            app.use(bodyParser.json({limit: '1mb', type: 'application/*+json' }));
            app.use(bodyParser.text({limit: '1mb', type: 'application/*+xml' }));

            http.globalAgent.maxSockets = 1000000;

            db.connect(usedbhost, 3306, 'root', usedbpass, function (rsc) {
                if(rsc == '1') {
                    http.createServer(app).listen({port: usecsebaseport, agent: false}, function () {
                        console.log('server (' + ip.address() + ') running at ' + usecsebaseport + ' port');
                        cb.create(function(rsp) {
                            console.log(JSON.stringify(rsp));
                        });
                    });
                }
            });

            /*            
            var port2 = 7589;
            var options = {
                key: fs.readFileSync('./key.pem'),
                cert: fs.readFileSync('./cert.pem')
            };

            https.createServer(options, app).listen(port2, function(){
                console.log("Https server listening on port " + port2);
            });
            */
        }
    });
}


function check_nametype(request, body_Obj) {
    if(request.headers.nmtype == 'long') {
        var rsrcLongName = Object.keys(body_Obj)[0].split(':')[1];
        if (responder.rsrcSname.hasOwnProperty(rsrcLongName)) {
            var rsrcShortName = responder.rsrcSname[rsrcLongName];
            body_Obj[rsrcShortName] = {};
            for(var index in body_Obj['m2m:'+rsrcLongName]) {
                if(index == "$") {
                    if(body_Obj['m2m:'+rsrcLongName][index]['resourceName'] != null) {
                        body_Obj[rsrcShortName].rn = body_Obj['m2m:' + rsrcLongName][index]['resourceName'];
                    }
                    delete body_Obj['m2m:'+rsrcLongName][index];
                    continue;
                }
                var attrShortName = responder.attrSname[index];

                if(index == 'eventNotificationCriteria') {
                    body_Obj[rsrcShortName][attrShortName] = {};
                    body_Obj[rsrcShortName][attrShortName][responder.attrSname['notificationEventType']] = body_Obj['m2m:'+rsrcLongName][index]['notificationEventType'];
                }
                else {
                    body_Obj[rsrcShortName][attrShortName] = body_Obj['m2m:' + rsrcLongName][index];
                }
                delete body_Obj['m2m:'+rsrcLongName][index];
            }
            delete body_Obj['m2m:'+rsrcLongName];
        }
        else {
            return '0';
        }
    }
    else {
        if(body_Obj[Object.keys(body_Obj)[0]]['$'] != null) {
            if(body_Obj[Object.keys(body_Obj)[0]]['$'].rn != null) {
                body_Obj[Object.keys(body_Obj)[0]].rn = body_Obj[Object.keys(body_Obj)[0]]['$'].rn;
            }
            delete body_Obj[Object.keys(body_Obj)[0]]['$'];
        }
        body_Obj[Object.keys(body_Obj)[0].split(':')[1]] = body_Obj[Object.keys(body_Obj)[0]];
        delete body_Obj[Object.keys(body_Obj)[0]];
    }
}

function check_acp(body_Obj) {
    if(body_Obj['acp']['pv'] != null) {
        if (!Array.isArray(body_Obj['acp']['pv']['acr'])) {
            var temp = body_Obj['acp']['pv']['acr'];
            body_Obj['acp']['pv']['acr'] = [];
            body_Obj['acp']['pv']['acr'][0] = temp;
        }

        for (var acr_idx in body_Obj.acp.pv.acr) {
            if (body_Obj.acp.pv.acr[acr_idx].acor) {
                body_Obj.acp.pv.acr[acr_idx].acor = body_Obj.acp.pv.acr[acr_idx].acor.split(' ');
            }
        }
    }

    if(body_Obj['acp']['pvs'] != null) {
        if (!Array.isArray(body_Obj['acp']['pvs']['acr'])) {
            temp = body_Obj['acp']['pvs']['acr'];
            body_Obj['acp']['pvs']['acr'] = [];
            body_Obj['acp']['pvs']['acr'][0] = temp;
        }

        for (var acr_idx in body_Obj.acp.pvs.acr) {
            if (body_Obj.acp.pvs.acr[acr_idx].acor) {
                body_Obj.acp.pvs.acr[acr_idx].acor = body_Obj.acp.pvs.acr[acr_idx].acor.split(' ');
            }
        }
    }
}

function check_http(request, response, callback) {
    var body_Obj = {};
    if (request.headers.nmtype == null) {
        request.headers.nmtype = 'short';
    }

    if( (request.headers['x-m2m-origin'] == null) ) {
        body_Obj['rsp'] = {};
        body_Obj['rsp'].cap = 'X-M2M-Origin is none';
        responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'X-M2M-Origin is none');
        callback('0', body_Obj);
        return '0';
    }

    if( (request.headers['x-m2m-ri'] == null) ) {
        body_Obj['rsp'] = {};
        body_Obj['rsp'].cap = 'X-M2M-RI is none';
        responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'X-M2M-RI is none');
        callback('0', body_Obj);
        return '0';
    }

    response.setHeader('X-M2M-RI', request.headers['x-m2m-ri']);

    if (request.headers.accept == null) {
        request.headers.usebodytype = defaultbodytype;
    }
    else {
        try {
            if ((request.headers.accept.split('/')[1] == 'xml') || (request.headers.accept.split('+')[1] == 'xml')) {
                request.headers.usebodytype = 'xml';
            }
            else {
                request.headers.usebodytype = 'json';
            }
        }
        catch(e) {
            request.headers.usebodytype = defaultbodytype;
        }
    }

    if(request.method == 'POST') {
        if(request.body == "") {
            body_Obj['rsp'] = {};
            body_Obj['rsp'].cap = 'body is empty';
            responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'body is empty');
            callback('0', body_Obj);
            return '0';
        }

        var content_type = request.headers['content-type'].split(';');

        // if(content_type[0].split('+')[0] != 'application/vnd.onem2m-res') {
        //     body_Obj['rsp'] = {};
        //     body_Obj['rsp'].cap = 'Content-Type is not match (application/vnd.onem2m-res)';
        //     responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'Content-Type is match (application/vnd.onem2m-res)');
        //     callback('0', body_Obj);
        //     return '0';
        // }

        try {
            var ty = content_type[1];
            ty = ty.split('=')[1];
        }
        catch (e) {
            if (ty == null || ty == '') {
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'ty is none';
                responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'ty is none');
                callback('0', body_Obj);
                return '0';
            }
        }

        //resource.set_rootnm(request, ty);
        //var rootnm = request.headers.rootnm;

        if ((content_type[0].split('/')[1] == 'xml') || (content_type[0].split('+')[1] == 'xml')) {
            request.headers.usebodytype = 'xml';

            var parser = new xml2js.Parser({explicitArray: false});
            parser.parseString(request.body, function (err, result) {
                if (err) {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'do not parse xml body';
                    responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'do not parse xml body');
                    callback('0', body_Obj);
                    return '0';
                }
                else {
                    body_Obj = result;
                    check_nametype(request, body_Obj);
                    if(ty == '1') {
                        check_acp(body_Obj);
                    }
                    callback(ty, body_Obj);
                }
            });
        }
        else {
            try {
                body_Obj = JSON.parse(request.body.toString());
                //if(body_Obj[rootnm] == null) {
                //    body_Obj[rootnm] = JSON.parse(request.body.toString());
                //}
                check_nametype(request, body_Obj);

                if(ty == '1') {
                    check_acp(body_Obj);
                }
                callback(ty, body_Obj);
            }
            catch (e) {
                body_Obj = {};
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'do not parse json body';
                responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'do not parse json body');
                callback('0', body_Obj);
                return '0';
            }
        }
    }
    else if(request.method == 'PUT') {
        if(request.body == "") {
            body_Obj['rsp'] = {};
            body_Obj['rsp'].cap = 'body is empty';
            responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'body is empty');
            callback('0', body_Obj);
            return '0';
        }

        try {
            content_type = request.headers['content-type'].split(';');
        }
        catch (e) {
            content_type = [];
            content_type[0] = 'application/'+defaultbodytype;
        }
        
        // if(content_type[0].split('+')[0] != 'application/vnd.onem2m-res') {
        //     body_Obj['rsp'] = {};
        //     body_Obj['rsp'].cap = 'Content-Type is none';
        //     responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'Content-Type is none');
        //     callback('0', body_Obj);
        //     return '0';
        // }

        if ((content_type[0].split('/')[1] == 'xml') || (content_type[0].split('+')[1] == 'xml')) {
            request.headers.usebodytype = 'xml';

            parser = new xml2js.Parser({explicitArray: false});
            parser.parseString(request.body, function (err, result) {
                if (err) {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'do not parse xml body';
                    responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'do not parse xml body');
                    callback('0', body_Obj);
                    return '0';
                }
                else {
                    body_Obj = result;
                    check_nametype(request, body_Obj);
                    if(Object.keys(body_Obj)[0] == 'acp') {
                        try {
                            check_acp(body_Obj);
                        }
                        catch (e) {
                            
                        }
                    }
                    callback(ty, body_Obj);
                }
            });
        }
        else {
            try {
                body_Obj = JSON.parse(request.body.toString());
                check_nametype(request, body_Obj);
                if(Object.keys(body_Obj)[0] == 'acp') {
                    check_acp(body_Obj);
                }
                callback(ty, body_Obj);
            }
            catch (e) {
                body_Obj = {};
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'do not parse json body';
                responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'do not parse json body');
                callback('0', body_Obj);
                return '0';
            }
        }
    }
    else if(request.method == 'GET' || request.method == 'DELETE') {
        var url_arr = url.parse(request.url).pathname.toLowerCase().split('/');
        var recent = url_arr[url_arr.length-1];
        if(recent == 'latest' || recent == 'la') {
            callback('latest', body_Obj);
        }
        else if(recent == 'oldest' || recent == 'ol') {
            callback('oldest', body_Obj);
        }
        else {
            callback('direct', body_Obj);
        }
    }
    else {
        callback('1', body_Obj);
    }
}

function check_resource(request, response, option, callback) {
    var body_Obj = {};
    var ri = url.parse(request.url).pathname.toLowerCase();

    var url_arr = url.parse(request.url).pathname.toLowerCase().split('/');
    var recent = url_arr[url_arr.length-1];

    if(option == null) {
        option = 'direct';
    }
    else if(option == 'latest') {
        if(recent == 'latest' || recent == 'la') {
            if (recent == 'latest') {
                ri = url.parse(request.url).pathname.replace('/latest', '');
            }
            else {
                ri = url.parse(request.url).pathname.replace('/la', '');
            }
        }
    }
    else if(option == 'oldest') {
        if(recent == 'oldest' || recent == 'ol') {
            if (recent == 'oldest') {
                ri = url.parse(request.url).pathname.replace('/oldest', '');
            }
            else {
                ri = url.parse(request.url).pathname.replace('/ol', '');
            }
        }
    }
    else {
        option = 'direct'
    }

    var queryJson = {};
    queryJson.type = 'select';
    queryJson.table = 'lookup';
    switch(option) {
        case 'direct':
            var sql = util.format("select * from lookup where ri = \'%s\'", ri);
            queryJson.condition = 'direct';
            break;
        case 'latest':
            sql = util.format("select * from lookup where pi = \'%s\' and (ty = '4' or ty = '26') order by ct desc limit 1", ri);
            queryJson.condition = 'latest';
            break;
        case 'oldest':
            sql = sql = util.format("select * from lookup where pi = \'%s\' and (ty = '4' or ty = '26') order by ct asc limit 1", ri);
            queryJson.condition = 'oldest';
            break;
    }
    
    db.getResult(sql, queryJson, function(err, results) {
        if(!err) {
            if (results.length == 1) {
                results[0].acpi = JSON.parse(results[0].acpi);
                results[0].lbl = JSON.parse(results[0].lbl);
                results[0].aa = JSON.parse(results[0].aa);
                results[0].at = JSON.parse(results[0].at);
                callback('1', results[0]);
            }
            else {
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'resource does not exist';
                responder.response_result(request, response, 404, body_Obj, 4004, url.parse(request.url).pathname.toLowerCase(), 'resource does not exist');
                callback('0');
                return '0';
            }
        }
        else {
            body_Obj['rsp'] = {};
            body_Obj['rsp'].cap = results.code;
            responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), results.code);
            callback('0');
            return '0';
        }
    });
}

function create_bodyListCheck(rootnm, body_Obj, results_comm) {
    if(!body_Obj[rootnm].acpi) {
        body_Obj[rootnm].acpi = [];
        for(var index in results_comm.acpi) {
            body_Obj[rootnm].acpi.push(results_comm.acpi[index]);
        }
    }
    else {
        if(!Array.isArray(body_Obj[rootnm].acpi)) {
            temp = body_Obj[rootnm].acpi;
            body_Obj[rootnm].acpi = [];
            var acpi_arr = temp.split(' ');
            for(idx in acpi_arr) {
                if(acpi_arr[idx] != '') {
                    body_Obj[rootnm].acpi.push(acpi_arr[idx]);
                }
            }
        }
        for(index in results_comm.acpi) {
            body_Obj[rootnm].acpi.push(results_comm.acpi[index]);
        }
    }

    if(!body_Obj[rootnm].lbl) {
        body_Obj[rootnm].lbl = [];
    }
    else {
        if(!Array.isArray(body_Obj[rootnm].lbl)) {
            temp = body_Obj[rootnm].lbl;
            body_Obj[rootnm].lbl = [];
            var lbl_arr = temp.split(' ');
            for(idx in lbl_arr) {
                if(lbl_arr[idx] != '') {
                    body_Obj[rootnm].lbl.push(lbl_arr[idx]);
                }
            }
        }
    }

    if(!body_Obj[rootnm].aa) {
        body_Obj[rootnm].aa = [];
    }
    else {
        if(!Array.isArray(body_Obj[rootnm].aa)) {
            temp = body_Obj[rootnm].aa;
            body_Obj[rootnm].aa = [];
            var aa_arr = temp.split(' ');
            for(idx in aa_arr) {
                if(aa_arr[idx] != '') {
                    body_Obj[rootnm].aa.push(aa_arr[idx]);
                }
            }
        }
    }

    if(!body_Obj[rootnm].at) {
        body_Obj[rootnm].at = [];
    }
    else {
        if(!Array.isArray(body_Obj[rootnm].at)) {
            temp = body_Obj[rootnm].at;
            body_Obj[rootnm].at = [];
            var at_arr = temp.split(' ');
            for(idx in at_arr) {
                if(at_arr[idx] != '') {
                    body_Obj[rootnm].at.push(at_arr[idx]);
                }
            }
        }
    }
}


function update_bodyListCheck(rootnm, body_Obj, results_comm) {
    if(!body_Obj[rootnm].acpi) {
        body_Obj[rootnm].acpi = [];
        for(var index in results_comm.acpi) {
            body_Obj[rootnm].acpi.push(results_comm.acpi[index]);
        }
    }
    else {
        if(!Array.isArray(body_Obj[rootnm].acpi)) {
            temp = body_Obj[rootnm].acpi;
            body_Obj[rootnm].acpi = [];
            var acpi_arr = temp.split(' ');
            for(idx in acpi_arr) {
                if(acpi_arr[idx] != '') {
                    body_Obj[rootnm].acpi.push(acpi_arr[idx]);
                }
            }
        }
    }

    if(!body_Obj[rootnm].lbl) {
        body_Obj[rootnm].lbl = [];
    }
    else {
        if(!Array.isArray(body_Obj[rootnm].lbl)) {
            temp = body_Obj[rootnm].lbl;
            body_Obj[rootnm].lbl = [];
            var lbl_arr = temp.split(' ');
            for(idx in lbl_arr) {
                if(lbl_arr[idx] != '') {
                    body_Obj[rootnm].lbl.push(lbl_arr[idx]);
                }
            }
        }
    }
}

/**
 *
 * @param request
 * @param response
 */
function lookup_create(request, response) {
    check_http(request, response, function(ty, body_Obj) {
        if(ty == '0') {
            return ty;
        }
        check_resource(request, response, 'direct', function (rsc, results_comm) {
            if(rsc == '0') {
                return rsc;
            }
            resource.set_rootnm(request, ty);
            var rootnm = request.headers.rootnm;
            if(rootnm != Object.keys(body_Obj)[0]) {
                body_Obj = {};
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'nametype does not match in body';
                responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'nametype does not match in body');
                return '0';
            }

            create_bodyListCheck(rootnm, body_Obj, results_comm);

            if ((ty == 1) && (results_comm.ty == 5 || results_comm.ty == 16 || results_comm.ty == 2)) { // accessControlPolicy
            }
            else if ((ty == 16) && (results_comm.ty == 5)) { // remoteCSE
            }
            else if ((ty == 10) && (results_comm.ty == 5)) { // locationPolicy
            }
            else if ((ty == 2) && (results_comm.ty == 5 || results_comm.ty == 16)) { // ae
            }
            else if ((ty == 3) && (results_comm.ty == 5 || results_comm.ty == 16 || results_comm.ty == 2 || results_comm.ty == 3)) { // container
            }
            else if ((ty == 23) && (results_comm.ty == 5 || results_comm.ty == 16 || results_comm.ty == 2 || results_comm.ty == 3 || results_comm.ty == 24 || results_comm.ty == 25)) { // sub
            }
            else if ((ty == 4) && (results_comm.ty == 3)) { // contentInstance
                if(results_comm.ty == 3) {
                    body_Obj[rootnm].mni = results_comm.mni;
                }
            }
            else if ((ty == 24) && (results_comm.ty == 2 || results_comm.ty == 3 || results_comm.ty == 4 || results_comm.ty == 25)) { // semanticDescriptor
            }
            else if ((ty == 25) && (results_comm.ty == 5 || results_comm.ty == 16 || results_comm.ty == 2)) { // timeSeries
            }
            else if ((ty == 26) && (results_comm.ty == 25)) { // timeSeriesInstance
                if(results_comm.ty == 25) {
                    body_Obj[rootnm].mni = results_comm.mni;
                }
            }
            else if ((ty == 27) && (results_comm.ty == 2 || results_comm.ty == 16)) { // multimediaSession
            }
            else {
                body_Obj = {};
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'ty does not be supported';
                responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'ty does not be supported');
                return '0';
            }
            security.check(request, results_comm.ty, results_comm.acpi, '1', function (rsc) {
                if (rsc == '0') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'ACCESS_DENIED';
                    responder.response_result(request, response, 403, body_Obj, 4103, url.parse(request.url).pathname.toLowerCase(), 'ACCESS_DENIED');
                    return '0';
                }
                resource.create(request, response, ty, body_Obj);
            });
        });
    });
}

function lookup_retrieve(request, response) {
    check_http(request, response, function(option, body_Obj) {
        if (option == '0') {
            return option;
        }
        check_resource(request, response, option, function (rsc, results_comm) {
            if (rsc == '0') {
                return rsc;
            }

            if(results_comm.ty == '1') {
                results_comm.acpi = [];
                results_comm.acpi[0] = results_comm.ri;
            }

            security.check(request, results_comm.ty, results_comm.acpi, '2', function (rsc) {
                if(rsc == '0') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'ACCESS_DENIED';
                    responder.response_result(request, response, 403, body_Obj, 4103, url.parse(request.url).pathname.toLowerCase(), 'ACCESS_DENIED');
                    return '0';
                }
                resource.retrieve(request, response, results_comm);
            });
        });
    });
}

function lookup_update(request, response) {
    check_http(request, response, function(option, body_Obj) {
        if (option == '0') {
            return option;
        }
        check_resource(request, response, 'direct', function (rsc, results_comm) {
            if (rsc == '0') {
                return rsc;
            }
            resource.set_rootnm(request, results_comm.ty);
            var rootnm = request.headers.rootnm;
            if(rootnm != Object.keys(body_Obj)[0]) {
                body_Obj = {};
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'nametype does not match in body';
                responder.response_result(request, response, 400, body_Obj, 4000, url.parse(request.url).pathname.toLowerCase(), 'nametype does not match in body');
                return '0';
            }

            update_bodyListCheck(rootnm, body_Obj, results_comm);

            if(results_comm.ty == '1') {
                results_comm.acpi = [];
                results_comm.acpi[0] = results_comm.ri;
            }

            security.check(request, results_comm.ty, results_comm.acpi, '4', function (rsc) {
                if (rsc == '0') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'ACCESS_DENIED';
                    responder.response_result(request, response, 403, body_Obj, 4103, url.parse(request.url).pathname.toLowerCase(), 'ACCESS_DENIED');
                    return '0';
                }
                resource.update(request, response, results_comm, body_Obj);
            });
        });
    });
}

function lookup_delete(request, response) {
    check_http(request, response, function(option, body_Obj) {
        if (option == '0') {
            return option;
        }
        check_resource(request, response, option, function (rsc, results_comm) {
            if (rsc == '0') {
                return rsc;
            }

            if(results_comm.ty == '1') {
                results_comm.acpi = [];
                results_comm.acpi[0] = results_comm.ri;
            }
            
            security.check(request, results_comm.ty, results_comm.acpi, '8', function (rsc) {
                if (rsc == '0') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'ACCESS_DENIED';
                    responder.response_result(request, response, 403, body_Obj, 4103, url.parse(request.url).pathname.toLowerCase(), 'ACCESS_DENIED');
                    return '0';
                }
                resource.delete(request, response, results_comm);
            });
        });
    });
}


var xmlParser = bodyParser.text({ limit: '1mb', type: 'application/onem2m-resource+xml;application/xml;application/json;application/vnd.onem2m-res+xml;application/vnd.onem2m-res+json' });
//var xmlParser = bodyParser.text({ limit: '1mb', type: '*/*' });


// remoteCSE, ae, cnt
app.post(xmlParser, function(request, response, next) {
    var fullBody = '';
    request.on('data', function(chunk) {
        fullBody += chunk.toString();
    });
    request.on('end', function() {
        request.body = fullBody;
        request.url = request.url.replace(/\/$/, "");
        var url_arr = url.parse(request.url).pathname.toLowerCase().split('/');
        var absolute_url = request.url.replace(/\/~\/[^\/]+\/?/, '/');

        if(url.parse(absolute_url).pathname.toLowerCase().split('/')[1] == usecsebase) {
            request.url = absolute_url;
            lookup_create(request, response);
        }
        else {
            check_csr(absolute_url, function (rsc, body_Obj) {
                if(rsc == '0') {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else if(rsc == '1') {
                    forward_http(body_Obj.forwardcbhost, body_Obj.forwardcbport, request, response);
                }
                else if(rsc == '2') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'forwarding with mqtt is not supported';
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
            });
        }
    });
});


app.get(xmlParser, function(request, response) {
    var fullBody = '';
    request.on('data', function(chunk) {
        fullBody += chunk.toString();
    });
    request.on('end', function() {
        request.body = fullBody;
        request.url = request.url.replace(/\/$/, "");
        var url_arr = url.parse(request.url).pathname.toLowerCase().split('/');
        var absolute_url = request.url.replace(/\/~\/[^\/]+\/?/, '/');

        if(url.parse(absolute_url).pathname.toLowerCase().split('/')[1] == usecsebase) {
            request.url = absolute_url;
            if (request.query.rcn == 0) {
                response.setHeader('X-M2M-RSC', '4000');
                response.status(400).end('<h1>Bad Request : rcn query is not be zero when request</h1>');
                response.status(400).end((request.headers.usebodytype == 'json') ? '{\"rsp\":\"Bad Request : rcn query is not be zero when request\"}' : '<rsp>Bad Request : rcn query is not be zero when request</rsp>');
            }
            else {
                lookup_retrieve(request, response);
            }
        }
        else {
            check_csr(absolute_url, function (rsc, body_Obj) {
                if(rsc == '0') {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else if(rsc == '1') {
                    forward_http(body_Obj.forwardcbhost, body_Obj.forwardcbport, request, response);
                }
                else if(rsc == '2') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'forwarding with mqtt is not supported';
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
            });
        }
    });
});


app.put(xmlParser, function(request, response, next) {
    var fullBody = '';
    request.on('data', function(chunk) {
        fullBody += chunk.toString();
    });
    request.on('end', function() {
        request.body = fullBody;
        request.url = request.url.replace(/\/$/, "");
        var url_arr = url.parse(request.url).pathname.toLowerCase().split('/');
        var absolute_url = request.url.replace(/\/~\/[^\/]+\/?/, '/');

        if(url.parse(absolute_url).pathname.toLowerCase() == ('/'+usecsebase)) {
            var body_Obj = {};
            body_Obj['rsp'] = {};
            body_Obj['rsp'].cap = 'OPERATION_NOT_ALLOWED';
            responder.response_result(request, response, 405, body_Obj, 4005, url.parse(request.url).pathname.toLowerCase(), 'OPERATION_NOT_ALLOWED');
        }
        else if(url.parse(absolute_url).pathname.toLowerCase().split('/')[1] == usecsebase) {
            request.url = absolute_url;
            lookup_update(request, response);
        }
        else {
            check_csr(absolute_url, function (rsc, body_Obj) {
                if(rsc == '0') {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else if(rsc == '1') {
                    forward_http(body_Obj.forwardcbhost, body_Obj.forwardcbport, request, response);
                }
                else if(rsc == '2') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'forwarding with mqtt is not supported';
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
            });
        }
    });
});

app.delete(xmlParser, function(request, response, next) {
    var fullBody = '';
    request.on('data', function(chunk) {
        fullBody += chunk.toString();
    });
    request.on('end', function() {
        request.body = fullBody;
        request.url = request.url.replace(/\/$/, "");
        var url_arr = url.parse(request.url).pathname.toLowerCase().split('/');
        var absolute_url = request.url.replace(/\/~\/[^\/]+\/?/, '/');

        if(url.parse(absolute_url).pathname.toLowerCase() == ('/'+usecsebase)) {
            var body_Obj = {};
            body_Obj['rsp'] = {};
            body_Obj['rsp'].cap = 'OPERATION_NOT_ALLOWED';
            responder.response_result(request, response, 405, body_Obj, 4005, url.parse(request.url).pathname.toLowerCase(), 'OPERATION_NOT_ALLOWED');
        }
        else if(url.parse(absolute_url).pathname.toLowerCase().split('/')[1] == usecsebase) {
            request.url = absolute_url;
            lookup_delete(request, response);
        }
        else {
            check_csr(absolute_url, function (rsc, body_Obj) {
                if(rsc == '0') {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else if(rsc == '1') {
                    forward_http(body_Obj.forwardcbhost, body_Obj.forwardcbport, request, response);
                }
                else if(rsc == '2') {
                    body_Obj = {};
                    body_Obj['rsp'] = {};
                    body_Obj['rsp'].cap = 'forwarding with mqtt is not supported';
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
                else {
                    responder.response_result(request, response, 500, body_Obj, 5000, url.parse(request.url).pathname.toLowerCase(), body_Obj['rsp'].cap);
                }
            });
        }
    });
});

function check_csr(absolute_url, callback) {
    var ri = util.format('/%s/%s', usecsebase.toLowerCase(), url.parse(absolute_url).pathname.toLowerCase().split('/')[1]);
    var sql = util.format("select * from csr where ri = \'%s\'", ri);
    db.getResult(sql, '', function (err, results) {
        if(!err) {
            if (results.length == 1) {
                var body_Obj = {};
                body_Obj.forwardcbname = results[0].cb.replace('/', '');
                var poa_arr = JSON.parse(results[0].poa);
                for (var i = 0; i < poa_arr.length; i++) {
                    if (url.parse(poa_arr[i]).protocol == 'http:') {
                        body_Obj.forwardcbhost = url.parse(poa_arr[i]).hostname;
                        body_Obj.forwardcbport = url.parse(poa_arr[i]).port;

                        console.log('csebase forwarding to ' + body_Obj.forwardcbname);

                        callback('1', body_Obj);
                    }
                    else if (url.parse(poa_arr[i]).protocol == 'mqtt:') {
                        body_Obj.forwardcbmqtt = url.parse(poa_arr[i]).hostname;

                        callback('2', body_Obj);
                    }
                    else {
                        body_Obj = {};
                        body_Obj['rsp'] = {};
                        body_Obj['rsp'].cap = 'poa of csr is not supported';
                        callback('0', body_Obj);
                        break;
                    }
                }
            }
            else {
                body_Obj = {};
                body_Obj['rsp'] = {};
                body_Obj['rsp'].cap = 'csebase is not found';
                callback('3', body_Obj);
            }
        }
        else {
            console.log('[check_csr] query error: ' + results.code);
        }
    });
}


function forward_http(forwardcbhost, forwardcbport, request, response) {
    var options = {
        hostname: forwardcbhost,
        port: forwardcbport,
        path: request.url,
        method: request.method,
        headers: request.headers
    };

    var req = http.request(options, function (res) {
        var fullBody = '';
        res.on('data', function(chunk) {
            fullBody += chunk.toString();
        });

        res.on('end', function() {
            console.log('[Forward response : ' + res.statusCode + ']');

            //response.headers = res.headers;
            if(res.headers['content-type']){
                response.setHeader('Content-Type', res.headers['content-type']);
            }
            if(res.headers['x-m2m-ri']){
                response.setHeader('X-M2M-RI', res.headers['x-m2m-ri']);
            }
            if(res.headers['x-m2m-rsc']){
                response.setHeader('X-M2M-RSC', res.headers['x-m2m-rsc']);
            }
            if(res.headers['content-location']){
                response.setHeader('Content-Location', res.headers['content-location']);
            }

            response.statusCode = res.statusCode;
            response.send(fullBody);
        });
    });

    req.on('error', function(e) {
        console.log('[forward_http] problem with request: ' + e.message);
    });

    // write data to request body
    if((request.method.toLowerCase() == 'get') || (request.method.toLowerCase() == 'delete')) {
        req.write('');
    }
    else {
        req.write(request.body);
    }
    req.end();
}


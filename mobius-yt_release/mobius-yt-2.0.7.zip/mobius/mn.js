/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * @copyright KETI Korea 2015, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var http = require('http');
var util = require('util');
var xml2js = require('xml2js');
var xmlbuilder = require('xmlbuilder');
var fs = require('fs');
var url = require('url');
var db = require('./db_action');

_this = this;


function self_create_remoteCSE(cb_jsonObj) {
    var node = {};
    if(defaultbodytype == 'xml') {
        if (defaultnmtype == 'long') {
            node[0] = xmlbuilder.create('m2m:remoteCSE', {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance').att('resourceName', cb_jsonObj["m2m:CSEBase"]['resourceName']);
            node[0].ele('cseType', cb_jsonObj['m2m:CSEBase']['cseType']);
            node[0].ele('CSE-ID', cb_jsonObj['m2m:CSEBase']['CSE-ID']);
            node[0].ele('pointOfAccess', cb_jsonObj['m2m:CSEBase']['pointOfAccess']);
            node[0].ele('requestReachability', 'true');
            node[0].ele('CSEBase', cb_jsonObj['m2m:CSEBase']['resourceName']);
            var poa_arr = cb_jsonObj['m2m:CSEBase']['pointOfAccess'].split(' ');
        }
        else { // defaultnmtype == 'short'
            node[0] = xmlbuilder.create('m2m:csr', {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance').att('rn', cb_jsonObj["m2m:cb"]['rn']);
            node[0].ele('cst', cb_jsonObj['m2m:cb']['cst']);
            node[0].ele('csi', cb_jsonObj['m2m:cb']['csi']);
            node[0].ele('poa', cb_jsonObj['m2m:cb']['poa']);
            node[0].ele('rr', 'true');
            node[0].ele('cb', cb_jsonObj['m2m:cb']['rn']);
            poa_arr = cb_jsonObj['m2m:cb']['poa'].split(' ');
        }

        // make comment because already know for information of IN-CSE
        //for (var i = 0; i < poa_arr.length; i++) {
        //    if (url.parse(poa_arr[i]).protocol == 'http:') {
        //        usecbhost = url.parse(poa_arr[i]).hostname;
        //        usecbhostport = url.parse(poa_arr[i]).port;
        //    }
        //    else if (url.parse(poa_arr[i]).protocol == 'mqtt:') {
        //        usecsemqtt = url.parse(poa_arr[i]).hostname;
        //
        //        pxymqtt.connect(usecsemqtt);
        //    }
        //}

        var bodyString = node[0].end({pretty: true, indent: '  ', newline: '\n'}).toString();

        var options = {
            hostname: 'localhost',
            port: usecsebaseport,
            path: '/' + usecsebase,
            method: 'post',
            headers: {
                'X-M2M-RI': '12345',
                'Accept': 'application/'+defaultbodytype,
                'X-M2M-Origin': 'Origin',
                'Content-Type': 'application/vnd.onem2m-res+'+defaultbodytype+'; ty=16'
            }
        };

        var req = http.request(options, function (res) {
            if(res.statusCode == 200) {
                NOPRINT == 'true' ? NOPRINT = 'true' : console.log('success to MN-CSE. csetype is MN-CSE');
            }
        });

        req.on('error', function (e) {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('problem with request: ' + e.message);
        });

        // write data to request body
        req.write(bodyString);
        req.end();
    }
    else { // defaultbodytype == 'json'
        if (defaultnmtype == 'long') {
            node['m2m:remoteCSE'] = {};
            node['m2m:remoteCSE'] = cb_jsonObj['m2m:CSEBase'];
            node['m2m:remoteCSE']['requestReachability'] = 'true';
            node['m2m:remoteCSE']['CSEBase'] = cb_jsonObj['m2m:CSEBase']['resourceName'];
            delete node['m2m:remoteCSE'].resourceID;
            delete node['m2m:remoteCSE'].lastModifiedTime;
            delete node['m2m:remoteCSE'].creationTime;
            delete node['m2m:remoteCSE'].resourceType;
        }
        else { // defaultnmtype == 'short'
            node['m2m:csr'] = {};
            node['m2m:csr'] = cb_jsonObj['m2m:cb'];
            node['m2m:csr']['rr'] = 'true';
            node['m2m:csr']['cb'] = cb_jsonObj['m2m:cb']['rn'];
            delete node['m2m:csr'].ri;
            delete node['m2m:csr'].lt;
            delete node['m2m:csr'].ct;
            delete node['m2m:csr'].ty;
        }

        bodyString = JSON.stringify(node);

        options = {
            hostname: 'localhost',
            port: usecsebaseport,
            path: '/' + usecsebase,
            method: 'post',
            headers: {
                'X-M2M-RI': '12345',
                'Accept': 'application/json',
                'X-M2M-Origin': 'Origin',
                'Content-Type': 'application/vnd.onem2m-res+json; ty=16'
            }
        };

        req = http.request(options, function (res) {
            var fullBody = '';
            res.on('data', function(chunk) {
                fullBody += chunk.toString();
            });

            res.on('end', function () {
                if (res.statusCode == 200 || res.statusCode == 201 || res.statusCode == 403 || res.statusCode == 409) {
                    console.log('success to MN-CSE. csetype is MN-CSE');
                }
            });
        });

        req.on('error', function (e) {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('problem with request: ' + e.message);
        });

        // write data to request body
        req.write(bodyString);
        req.end();
    }
}

function retrieve_CSEBase() {
    if (defaultbodytype == 'xml') {
        var ri = '/' + usecbname;
        var options = {
            hostname: usecbhost,
            port: usecbhostport,
            path: ri,
            method: 'get',
            headers: {
                'X-M2M-RI': '12345',
                'Accept': 'application/xml',
                'X-M2M-Origin': 'Origin',
                'nmtype': defaultnmtype
            }
        };

        var req = http.request(options, function (res) {
            var fullBody = '';
            res.on('data', function(chunk) {
                fullBody += chunk.toString();
            });

            res.on('end', function () {
                if (res.statusCode == 200) {
                    var parser = new xml2js.Parser({explicitArray: false});
                    parser.parseString(fullBody, function (err, result) {
                        if (err) {
                            console.log('[retrieve_CSEBase] fail to set csetype to MN-CSE. csetype is IN-CSE');
                        }
                        else {
                            result['m2m:cb'].rn = result['m2m:cb']['$'].rn;
                            var jsonString = JSON.stringify(result);
                            var jsonObj = JSON.parse(jsonString);
                            self_create_remoteCSE(jsonObj);
                        }
                    });
                }
            });
        });

        req.on('error', function (e) {
            console.log('problem with request: ' + e.message);
        });

        // write data to request body
        req.write('');
        req.end();
    }
    else { // defaultbodytype == 'json'
        ri = '/' + usecbname;
        options = {
            hostname: usecbhost,
            port: usecbhostport,
            path: ri,
            method: 'get',
            headers: {
                'locale': 'ko',
                'X-M2M-RI': '12345',
                'Accept': 'application/json',
                'X-M2M-Origin': 'Origin',
                'nmtype': defaultnmtype
            }
        };

        req = http.request(options, function (res) {
            var fullBody = '';
            res.on('data', function(chunk) {
                fullBody += chunk.toString();
            });

            res.on('end', function () {
                if (res.statusCode == 200) {
                    var jsonObj = JSON.parse(fullBody);

                    self_create_remoteCSE(jsonObj);
                }
            });
        });

        req.on('error', function (e) {
            console.log('problem with request: ' + e.message);
        });

        // write data to request body
        req.write('');
        req.end();
    }
}

function create_remoteCSE(results_cb) {
    var node = {};
    if(defaultbodytype == 'xml') {
        if (defaultnmtype == 'long') {
            node[results_cb[0].ri] = xmlbuilder.create('m2m:remoteCSE', {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance').att('resourceName', results_cb[0].rn);
            node[results_cb[0].ri].ele('cseType', results_cb[0].cst);
            node[results_cb[0].ri].ele('CSE-ID', results_cb[0].csi);
            node[results_cb[0].ri].ele('pointOfAccess', results_cb[0].poa);
            node[results_cb[0].ri].ele('requestReachability', 'true');
            node[results_cb[0].ri].ele('CSEBase', usecsebase);
        }
        else { // defaultnmtype == 'short'
            node[results_cb[0].ri] = xmlbuilder.create('m2m:csr', {version: '1.0', encoding: 'UTF-8', standalone: true},
                {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
            ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance').att('rn', results_cb[0].rn);
            node[results_cb[0].ri].ele('cst', results_cb[0].cst);
            node[results_cb[0].ri].ele('csi', results_cb[0].csi);
            node[results_cb[0].ri].ele('poa', results_cb[0].poa.replace('[', '').replace(/,/g, ' ').replace(/\"/g, '').replace(']', ''));
            node[results_cb[0].ri].ele('rr', 'true');
            node[results_cb[0].ri].ele('cb', usecsebase);
        }

        var bodyString = node[results_cb[0].ri].end({pretty: true, indent: '  ', newline: '\n'}).toString();
    }
    else { // defaultbodytype == 'json'
        if (defaultnmtype == 'long') {
            node['m2m:remoteCSE'] = results_cb[0];
            node['m2m:remoteCSE'].requestReachability = 'true';
            node['m2m:remoteCSE'].CSEBase = usecsebase;
            node['m2m:remoteCSE'].resourceName = usecsebase;
            delete node['m2m:remoteCSE'].ri;
        }
        else { // defaultnmtype == 'short'
            node['m2m:csr'] = results_cb[0];
            node['m2m:csr'].rr = 'true';
            node['m2m:csr'].cb = usecsebase;
            node['m2m:csr'].rn = usecsebase;
            delete node['m2m:csr'].ri;
        }

        bodyString = JSON.stringify(node);
    }

    var ri = '/' + usecbname;
    var options = {
        hostname: usecbhost,
        port: usecbhostport,
        path: ri,
        method: 'post',
        headers: {
            'X-M2M-RI': 'alkdflka',
            'Accept': 'application/'+defaultbodytype,
            'X-M2M-Origin': '1000',
            'Content-Type': 'application/'+defaultbodytype+';ty=16',
            'nmtype': defaultnmtype
        }
    };

    bodyString = bodyString.replace(/\\/g, '');

    var req = http.request(options, function (res) {
        var fullBody = '';
        res.on('data', function(chunk) {
            fullBody += chunk.toString();
        });
        res.on('end', function() {
            if (res.statusCode == 200 || res.statusCode == 201 || res.statusCode == 403 || res.statusCode == 409 || res.statusCode == 400) {
                retrieve_CSEBase(res);
            }
            else {
                console.log('MN : response status code error for create remoteCSE : ' + res.statusCode);
            }
        });
    });

    req.on('error', function (e) {
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log('problem with request: ' + e.message);
    });

    // write data to request body
    req.write(bodyString);
    req.end();
}

exports.build_mn = function(ri, callback) {
    // check remotecse if parent cse exist
    var rspObj = {};
    var sql = util.format("select * from lookup where ri = \'%s\'", ri);
    db.getResult(sql, '', function (err, results_comm) {
        if(!err) {
            if (results_comm.length == 0) {
                sql = util.format("select * from cb where ri = \'/%s\'", usecsebase);
                db.getResult(sql, '', function (err, results_cb) {
                    if(!err) {
                        if (results_cb.length == 1) {
                            results_cb[0].rn = usecsebase;
                            create_remoteCSE(results_cb);
                        }
                    }
                    else {
                        rspObj.rsc = '5000';
                        rspObj.ri = ri;
                        rspObj.sts = results_cb.code;
                        callback(rspObj);
                    }
                });
            }
            else {
                rspObj.rsc = '2001';
                rspObj.ri = ri;
                rspObj.sts = '';
                callback(rspObj);
            }
        }
        else {
            rspObj.rsc = '5000';
            rspObj.ri = ri;
            rspObj.sts = results_comm.code;
            callback(rspObj);
        }
    });
};

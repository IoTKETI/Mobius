/**
 * Copyright (c) 2015, OCEAN
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * @copyright KETI Korea 2015, OCEAN
 * @author Il Yeup Ahn [iyahn@keti.re.kr]
 */

var util = require('util');
var url = require('url');
var http = require('http');
var js2xmlparser = require('js2xmlparser');
var xmlbuilder = require('xmlbuilder');
var mqtt = require('mqtt');
var DB = require('./db_action');

var get_retrieve = require('./retrieve');

var ss_fail_count = {};

exports.check = function(request, pool, results_noti, level, parentpath) {
    var sql = util.format('select resourceid, eventnotificationcriteria, notificationcontenttype, notificationuri, path from lv%s where parentpath = \'%s\' and resourcetype = \'23\' order by resourceid desc limit 20', level + 1, parentpath);
    DB.getResult(pool, sql, function (err, results_ss) {
        if(!err) {
            for (var i = 0; i < results_ss.length; i++) {
                if (ss_fail_count[results_ss[i].resourceid] == null) {
                    ss_fail_count[results_ss[i].resourceid] = 0;
                }
                ss_fail_count[results_ss[i].resourceid]++;
                if (ss_fail_count[results_ss[i].resourceid] >= 16) {
                    delete ss_fail_count[results_ss[i].resourceid];
                    delete_SS(results_ss[i].path);
                }
                else {
                    var eventnotificationcriteria_jsonObj = JSON.parse(results_ss[i].eventnotificationcriteria);
                    if (eventnotificationcriteria_jsonObj.eventType == 3 || eventnotificationcriteria_jsonObj.evt == 3) { // Create_of_Direct_Child_Resource
                        var notificationuri = results_ss[i].notificationuri;
                        var sub_nu = url.parse(notificationuri);
                        var notificationcontenttype = results_ss[i].notificationcontenttype;

                        var node = {};
                        if (notificationcontenttype == 2) {
                            if(defaultbodytype == 'xml') {
                                node[0] = xmlbuilder.create('m2m:notification', {version: '1.0', encoding: 'UTF-8', standalone: true},
                                    {pubID: null, sysID: null}, {allowSurrogateChars: false, skipNullAttributes: false, headless: false, ignoreDecorators: false, stringify: {}}
                                ).att('xmlns:m2m', 'http://www.onem2m.org/xml/protocols').att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance');

                                var rootnm = '';
                                if(results_noti[0].resourcetype == 16) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:remoteCSE': rootnm = 'm2m:csr';
                                    node[1] = node[0].ele(rootnm);
                                    get_retrieve.addele_rc(request, node[1], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 2) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:AE': rootnm = 'm2m:ae';
                                    node[1] = node[0].ele(rootnm);
                                    get_retrieve.addele_ae(request, node[1], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 3) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:container': rootnm = 'm2m:cnt';
                                    node[1] = node[0].ele(rootnm);
                                    get_retrieve.addele_co(request, node[1], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 4) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:contentInstance': rootnm = 'm2m:cin';
                                    node[1] = node[0].ele(rootnm);
                                    get_retrieve.addele_ci(request, node[1], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 23) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:subscription': rootnm = 'm2m:sub';
                                    node[1] = node[0].ele(rootnm);
                                    get_retrieve.addele_ss(request, node[1], results_noti[0]);
                                }
                                else {

                                }

                                var xmlString = node[0].end({pretty: true, indent: '  ', newline: '\n'}).toString();

                                if(sub_nu.protocol == 'http:') {
                                    request_SS(notificationuri, results_ss[i].resourceid, xmlString, results_ss[i].path);
                                }
                                else { // mqtt:
                                    request_SS_mqtt(sub_nu.hostname, notificationuri, results_ss[i].resourceid, xmlString, results_ss[i].path);
                                }
                            }
                            else { // defaultbodytype == 'json')
                                rootnm = '';
                                if(results_noti[0].resourcetype == 16) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:remoteCSE': rootnm = 'm2m:csr';
                                    node[rootnm] = {};
                                    get_retrieve.addele_rc_json(request, node[rootnm], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 2) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:AE': rootnm = 'm2m:ae';
                                    node[rootnm] = {};
                                    get_retrieve.addele_ae_json(request, node[rootnm], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 3) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:container': rootnm = 'm2m:cnt';
                                    node[rootnm] = {};
                                    get_retrieve.addele_co_json(request, node[rootnm], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 4) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:contentInstance': rootnm = 'm2m:cin';
                                    node[rootnm] = {};
                                    get_retrieve.addele_ci_json(request, node[rootnm], results_noti[0]);
                                }
                                else if(results_noti[0].resourcetype == 23) {
                                    (request.headers.nmtype == 'long') ? rootnm = 'm2m:subscription': rootnm = 'm2m:sub';
                                    node[rootnm] = {};
                                    get_retrieve.addele_ss_json(request, node[rootnm], results_noti[0]);
                                }
                                else {

                                }

                                if(sub_nu.protocol == 'http:') {
                                    request_SS(notificationuri, results_ss[i].resourceid, JSON.stringify(node), results_ss[i].path);
                                }
                                else { // mqtt:
                                    request_SS_mqtt(sub_nu.hostname, notificationuri, results_ss[i].resourceid, JSON.stringify(node), results_ss[i].path);
                                }
                            }
                        }
                        else {
                            console.log('notificationContentType except 2 do not support');
                        }
                    }
                    else {
                        console.log('eventNotificationCriteria-eventType except 3 do not support');
                    }
                }
            }
        }
        else {
            console.log('query error: ' + results_ss.code);
        }
    });
};

function request_SS(notificationuri, ri, xmlString, path) {
    var options = {
        hostname: url.parse(notificationuri).hostname,
        port: url.parse(notificationuri).port,
        path: url.parse(notificationuri).path,
        method: 'POST',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': ri,
            'Accept': 'application/'+defaultbodytype,
            'X-M2M-Origin': path,
            'Content-Type': 'application/vnd.onem2m-ntfy+'+defaultbodytype
        }
    };

    var req = http.request(options, function (res) {
        //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('STATUS: ' + res.statusCode);
        //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('HEADERS: ' + JSON.stringify(res.headers));
        res.setEncoding('utf8');
        ss_fail_count[res.headers['x-m2m-ri']] = 0;
        if(res.statusCode == 200 || res.statusCode == 201) {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('[SS notification] ' + res.headers['x-m2m-ri'] + ' --> ' + notificationuri);

            //NOPRINT == 'true' ? NOPRINT = 'true' : console.log(res.headers['x-m2m-ri']);
            ss_fail_count[res.headers['x-m2m-ri']] = 0;
        }

        res.on('data', function (chunk) {
            //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('body: ' + chunk);
        });
    });

    req.on('error', function (e) {
        if(e.message != 'read ECONNRESET') {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('problem with request: ' + e.message);
        }
    });

    // write data to request body
    //NOPRINT == 'true' ? NOPRINT = 'true' : console.log(xmlString);
    req.write(xmlString);
    req.end();
}

function delete_SS(path) {
    var options = {
        hostname: 'localhost',
        port: '7579',
        path: path,
        method: 'delete',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': '12345',
            'Accept': 'application/'+defaultbodytype,
            'X-M2M-Origin': usecseid
        }
    };

    var req = http.request(options, function(res) {
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log('STATUS: ' + res.statusCode);
        //NOPRINT == 'true' ? NOPRINT = 'true' : console.log('HEADERS: ' + JSON.stringify(res.headers));
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('body: ' + chunk);
        });
    });

    req.on('error', function (e) {
        if(e.message != 'read ECONNRESET') {
            NOPRINT == 'true' ? NOPRINT = 'true' : console.log('problem with request: ' + e.message);
        }
    });

    // write data to request body
    req.write('');
    req.end();
}

function request_SS_mqtt(serverip, notificationuri, ri, inpc, path) {
    var mqtt_client = mqtt.connect('mqtt://' + serverip);
    var appid = url.parse(notificationuri).pathname;
    var sub_topic = util.format('/oneM2M/noti%s/%s', appid, path.toString().split('/')[3]);
    var rsp_topic = util.format('/oneM2M/resp%s/%s', appid, path.toString().split('/')[3]);

    mqtt_client.on('connect', function () {

        mqtt_client.subscribe(rsp_topic);

        var noti_message = {};
        noti_message.op = 5; // notification
        noti_message.to = appid;
        noti_message.fr = usecseid;
        noti_message.ri = ri;
        noti_message.pc = inpc;

        if(defaultbodytype == 'xml') {
            noti_message['@'] = {
                "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
            };

            var xmlString = js2xmlparser("m2m:noti", noti_message);

            mqtt_client.publish(sub_topic, xmlString);
        }
        else { // defaultbodytpye == 'json'
            mqtt_client.publish(sub_topic, JSON.stringify(noti_message));
        }
    });


    mqtt_client.on('message', function (topic, message) {
        // message is Buffer
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log(message.toString());
        var message_str = JSON.stringify(message.toString());
        var message_obj = JSON.parse(message.toString());
        ss_fail_count[message_obj.ri] = 0;
        NOPRINT == 'true' ? NOPRINT = 'true' : console.log('mqtt publish - ' + sub_topic);

        mqtt_client.end();
    });
}



/**
 * Created by ryeubi on 2015-10-19.
 */

var mysql = require('mysql');

exports.connect = function (host, port, user, password) {
    return mysql.createPool({
        host: host,
        port: port,
        user: user,
        password: password,
        database: 'mobiusdb',
        connectionLimit: 100,
        waitForConnections: true,
        debug: false,
        acquireTimeout: 50000,
        queueLimit: 0
    });
};


function executeQuery(pool, query, callback) {
    pool.getConnection(function (err, connection) {
        if (err) {
            return callback(err, null);
        }
        else if (connection) {
            connection.query({sql:query, timeout:60000}, function (err, rows, fields) {
                connection.release();
                if (err) {
                    return callback(err, null);
                }
                return callback(null, rows);
            })
        }
        else {
            return callback(true, "No Connection");
        }
    });
}


exports.getResult = function(pool, query, callback) {
    executeQuery(pool, query, function (err, rows) {
        if (!err) {
            callback(null,rows);
        }
        else {
            callback(true,err);
        }
    });
};

